<div id="main-nav-container">
            <div  class="container">
            <nav class="navbar navbar-eden" id="topnav">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                data-target="#main-menu">
                            <span class="sr-only"><?php echo $webtitle ?></span>
                            <i class="tn-menu"></i>
                        </button>
                        <a class="navbar-brand" href="#"><h4><?php echo $webtitle ?>&nbsp;&nbsp;&nbsp;&nbsp;</h4></a>
                    </div>

                    <div class="collapse navbar-collapse" id="main-menu">
                        <ul class="nav navbar-nav">
						    
                            <li class="active"><a href="index.php">主页</a></li>
                            <li><a href="index.php#why-us">介绍</a></li>
							<li><a href="index.php#client-reviews">常见问题</a></li>
                            <li><a href="index.php#pricing">价格</a></li>
                            

                        </ul>
                        <ul class="nav navbar-nav navbar-right">
                            <li><a target="_blank" href="/user/login.php">登录</a></li>
							<li><a target="_blank" href="/user/reg.php" >注册</a></li>
                        </ul>
                        
                    </div>
                </div>
            </nav>
            </div>
        </div>