<?php
$rs=$DB->get_row("SELECT * FROM website");
$logo=$rs['logo'];
$webtitle=$rs['title'];
$qq=$rs['qq'];
$app1=$rs['app1'];
$app2=$rs['app2'];
$ipinfo=$rs['ipinfo'];
$appleid1=$rs['appleid1'];
$appleps1=$rs['appleps1'];
$appleid2=$rs['appleid2'];
$appleps2=$rs['appleps2'];
$appleid3=$rs['appleid3'];
$appleps3=$rs['appleps3'];
$and_img1=$rs['and_img1'];
$and_img2=$rs['and_img2'];
$and_img3=$rs['and_img3'];
$and_img4=$rs['and_img4'];
$jia1=$rs['jia1'];
$jia2=$rs['jia2'];
$jia3=$rs['jia3'];
$jia4=$rs['jia4'];

$bn=$DB->get_row("SELECT * FROM banner");
$img1=$bn['img1'];
$tit1=$bn['tit1'];
$info1=$bn['info1'];
$img2=$bn['img2'];
$tit2=$bn['tit2'];
$info2=$bn['info2'];
$img3=$bn['img3'];
$tit3=$bn['tit3'];
$info3=$bn['info3'];

    //赠送新注册用户流量
    $rs=$DB->get_row("SELECT * FROM auth_config");
    $reg_cash_con=round($rs['reg_cash']/1024/1024)."MB";
    $user_endtime_con =$rs['user_endtime'];

?>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title><?php echo $webtitle ?> - <?php echo $title ?></title>
  <meta name="keywords" content="<?php echo $webtitle ?>,<?php echo $webtitle ?>缤纷云控,<?php echo $webtitle ?>全国流量特价,<?php echo $webtitle ?>流量包月,<?php echo $webtitle ?>4G流量" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="css/bootstrap.css" media="screen">
    <link rel="stylesheet" href="skins/eden.css" media="screen">
    <link rel="stylesheet" href="style.css" media="screen">
    <link href="fonts/icons/icons.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">

</head>