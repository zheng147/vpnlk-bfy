<?php
$mod='blank';
include("../api.inc.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="大猫哥快流量" />
  <meta name="author" content="" />
  <title>
  <?php
  $rs=$DB->get_row("SELECT * FROM website");
  $webtitle=$rs['title'];
   echo $webtitle
    ?> - 流量平台</title>

  <!-- <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Arimo:400,700,400italic">-->
  <link rel="stylesheet" href="../assets/css/fonts/linecons/css/linecons.css">
  <link rel="stylesheet" href="../assets/css/fonts/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../assets/css/bootstrap.css">
  <link rel="stylesheet" href="../assets/css/xenon-core.css">
  <link rel="stylesheet" href="../assets/css/xenon-forms.css">
  <link rel="stylesheet" href="../assets/css/xenon-components.css">
  <link rel="stylesheet" href="../assets/css/xenon-skins.css">
  <link rel="stylesheet" href="../assets/css/custom.css">

  <script src="../assets/js/jquery-1.11.1.min.js"></script>

  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

</head>
<body class="page-body">

<?php
$u = daddslashes($_GET['user']);
$p = daddslashes($_GET['pass']);
$res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
if(!$res){
//  header('location: login.php');
    echo '<div class="alert alert-info">
                    <button type="button" class="close" data-dismiss="alert">
                      <span aria-hidden="true">×</span>
                      <span class="sr-only">Close</span>
                    </button>
                    
                    <strong>您好!</strong> 您还未登录！
                  </div><style>#index{display: none;}</style>';
}





$title='用户中心';


$config = $DB->get_row("SELECT * FROM auth_config");
$gonggao=$config['ggs'];//公告获取

/*获取代理信息*/
$daili_info = $DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}'");
$daili_info_id=$daili_info['dlid'];
//echo "<script language='javascript'>alert('获取代理信息：".$daili_info_id."');</script>";

if($daili_info_id){
  $config_dl = $DB->get_row("SELECT * FROM auth_daili WHERE id='$daili_info_id' limit 1");
  $config_name=$config_dl['name'];//代理姓名
  $config_qq=$config_dl['qq'];
  $config_tel=$config_dl['tel'];
  $config_buy=$config_dl['buy'];//购买链接
  $config_buy2=$config_dl['buy2'];//购买代码
  //echo "<script language='javascript'>alert('获取代理信息：".$config_name."');</script>";
}else{
  $rs=$DB->get_row("SELECT * FROM website");
  $config_name=$rs['title'];
  $config_qq=$rs['qq'];
  $config_tel=$rs['tel'];

  $rs2=$DB->get_row("SELECT * FROM auth_config");
  $config_buy=$rs2['shopUrl'];
  $config_buy2=$rs2['shopCode'];
}

/*获取支付宝*/
$alpay= $DB->get_row("SELECT * FROM alipay");
$alpay_on=$alpay['partner'];

?>

  <div class="page-container" id="index">
    
    <div class="main-content">
          
      <?php include 'info.php';?>

      <div class="row">
        <div class="col-sm-12">
              <div class="btn-group btn-group-justified">         
                <a type="button" href="<?php echo "http://".$_SERVER ['HTTP_HOST']."/user/index.php?user=".$u."&pass=".$p."" ?>" class="btn btn-info"><i class="fa fa-user"></i> 会员中心</a>
                <a type="button" href="<?php echo $config_buy?>" class="btn btn-warning"><i class="fa fa-shopping-cart"></i> 购买流量</a>
                <a type="button" href="<?php echo "http://".$_SERVER ['HTTP_HOST']."/down/help.php?user=".$u."&pass=".$p."" ?>" class="btn btn-purple"><i class="fa fa-search"></i> 使用说明</a>
              </div>
              <br>
        </div>
      </div>      

      <div class="row">
        <div class="col-sm-12">
            <div class="alert alert-success">
              <button type="button" class="close" data-dismiss="alert">
                <span aria-hidden="true">×</span>
                <span class="sr-only">Close</span>
              </button>
              
              <strong>公告：</strong> <?php echo $gonggao;?>
            </div>
        </div>
      </div>

      <div class="row">
        <div class="col-sm-12">
          <ul class="nav nav-tabs nav-tabs-justified">
            <li class="active">
              <a href="#home-3" data-toggle="tab">
                <span class="visible-xs">移动</span>
                <span class="hidden-xs">移动</span>
              </a>
            </li>
            <li>
              <a href="#profile-3" data-toggle="tab">
                <span class="visible-xs">联通</span>
                <span class="hidden-xs">联通</span>
              </a>
            </li>
            <li>
              <a href="#messages-3" data-toggle="tab">
                <span class="visible-xs">电信</span>
                <span class="hidden-xs">电信</span>
              </a>
            </li>
          </ul>
          <div class="tab-content">
            <div class="tab-pane active" id="home-3">
              
            <table class="table">
              <tbody>
<?php
$res=$DB->query("SELECT * FROM `open` WHERE  `type` = 1 ");
while($open = $DB->fetch($res)){
echo '
                <tr>
                  <td class="middle-align">';
                  echo $open['name'];
     echo   '</td>
                  <td style="text-align: right;">
                    <a href="/admin/down.php?id=';
    echo $open['id'];
    echo '" class="btn btn-turquoise btn-single btn-sm">安装</a>
                  </td>
                </tr>';
}
?>
              </tbody>
            </table>
              
            </div>
            <div class="tab-pane" id="profile-3">
              
            <table class="table">
              <tbody>
<?php
$res=$DB->query("SELECT * FROM `open` WHERE  `type` = 2 ");
while($open = $DB->fetch($res)){
echo '
                <tr>
                  <td class="middle-align">';
                  echo $open['name'];
     echo   '</td>
                  <td style="text-align: right;">
                    <a href="/admin/down.php?id=';
    echo $open['id'];
    echo '" class="btn btn-turquoise btn-single btn-sm">安装</a>
                  </td>
                </tr>';
}
?>
              </tbody>
            </table>
                
            </div>
            <div class="tab-pane" id="messages-3">
              
            <table class="table">
              <tbody>
<?php
$res=$DB->query("SELECT * FROM `open` WHERE  `type` = 3 ");
while($open = $DB->fetch($res)){
echo '
                <tr>
                  <td class="middle-align">';
                  echo $open['name'];
     echo   '</td>
                  <td style="text-align: right;">
                    <a href="/admin/down.php?id=';
    echo $open['id'];
    echo '" class="btn btn-turquoise btn-single btn-sm">安装</a>
                  </td>
                </tr>';
}
?>
              </tbody>
            </table>
          
            </div>
            
          </div>
        </div>
      </div>

    </div>
    
  </div>

<?php include("../user/js.php");?>
</body>
</html>