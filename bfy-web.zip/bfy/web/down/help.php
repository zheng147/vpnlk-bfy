<?php
$mod='blank';
include("../api.inc.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="大猫哥快流量" />
  <meta name="author" content="" />
  <title>
  <?php
  $rs=$DB->get_row("SELECT * FROM website");
  $webtitle=$rs['title'];
   echo $webtitle
    ?> - 流量平台</title>

  <!-- <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Arimo:400,700,400italic">-->
  <link rel="stylesheet" href="../assets/css/fonts/linecons/css/linecons.css">
  <link rel="stylesheet" href="../assets/css/fonts/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../assets/css/bootstrap.css">
  <link rel="stylesheet" href="../assets/css/xenon-core.css">
  <link rel="stylesheet" href="../assets/css/xenon-forms.css">
  <link rel="stylesheet" href="../assets/css/xenon-components.css">
  <link rel="stylesheet" href="../assets/css/xenon-skins.css">
  <link rel="stylesheet" href="../assets/css/custom.css">

  <script src="../assets/js/jquery-1.11.1.min.js"></script>

  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

</head>
<body class="page-body">

<?php
$u = daddslashes($_GET['user']);
$p = daddslashes($_GET['pass']);
$res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
if(!$res){
//  header('location: login.php');
    echo '<div class="alert alert-info">
                    <button type="button" class="close" data-dismiss="alert">
                      <span aria-hidden="true">×</span>
                      <span class="sr-only">Close</span>
                    </button>
                    
                    <strong>您好!</strong> 您还未登录！
                  </div><style>#index{display: none;}</style>';
}





$title='用户中心';


$config = $DB->get_row("SELECT * FROM auth_config");
$gonggao=$config['ggs'];//公告获取

/*获取代理信息*/
$daili_info = $DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}'");
$daili_info_id=$daili_info['dlid'];
//echo "<script language='javascript'>alert('获取代理信息：".$daili_info_id."');</script>";

if($daili_info_id){
  $config_dl = $DB->get_row("SELECT * FROM auth_daili WHERE id='$daili_info_id' limit 1");
  $config_name=$config_dl['name'];//代理姓名
  $config_qq=$config_dl['qq'];
  $config_tel=$config_dl['tel'];
  $config_buy=$config_dl['buy'];//购买链接
  $config_buy2=$config_dl['buy2'];//购买代码
  //echo "<script language='javascript'>alert('获取代理信息：".$config_name."');</script>";
}else{
  $rs=$DB->get_row("SELECT * FROM website");
  $config_name=$rs['title'];
  $config_qq=$rs['qq'];
  $config_tel=$rs['tel'];

  $rs2=$DB->get_row("SELECT * FROM auth_config");
  $config_buy=$rs2['shopUrl'];
  $config_buy2=$rs2['shopCode'];
}

/*获取支付宝*/
$alpay= $DB->get_row("SELECT * FROM alipay");
$alpay_on=$alpay['partner'];

?>

  <div class="page-container" id="index">
    
    <div class="main-content">
          
      <?php include 'info.php';?>

      <div class="row">
        <div class="col-sm-12">
              <div class="btn-group btn-group-justified">         
                <a type="button" href="<?php echo "http://".$_SERVER ['HTTP_HOST']."/user/index.php?user=".$u."&pass=".$p."" ?>" class="btn btn-info"><i class="fa fa-user"></i> 会员中心</a>
                <a type="button" href="<?php echo $config_buy?>" class="btn btn-warning"><i class="fa fa-shopping-cart"></i> 购买流量</a>
                <a type="button" href="<?php echo "http://".$_SERVER ['HTTP_HOST']."/down/help.php?user=".$u."&pass=".$p."" ?>" class="btn btn-purple"><i class="fa fa-search"></i> 使用说明</a>
              </div>
              <br>
        </div>
      </div>  

      <div class="row">
        <div class="col-sm-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              流量软件APP操作方法和注意事项
            </div>
            
            <div class="panel-body">
              
              <div><b>电信版说明：</b></div><div>请电信客户使用前，点击开通<b><a href="http://www.189.cn/dqmh/web/zhidao/net_kng_detail.jsp?type=7&city=gd&area=&qid=1456560">爱听</a></b>、<b><a href="http://www.189.cn/dqmh/web/zhidao/net_kng_detail.jsp?type=7&city=gd&area=&qid=1609759">爱玩</a></b>、<b><a href="http://www.189.cn/dqmh/web/zhidao/net_kng_detail.jsp?type=7&city=gd&area=&qid=1563306">爱看</a></b>业务。<br></div><div><br><b>操作步骤：</b></div><div>打开APP,点击软件里的“账号”输入充值卡上的账号和密码，点击保存密码（一定要在保存密码上打√），再点击确定</div><div>点击软件里的“连接”当软件里面显示“已连接”，即安装成功。如果出现网关错误的地区，可尝试切换线路B或者线路C。一般大部分地区都是默认线路A，如果线路A连接不上可切换至线路B或者线路C（建议优先选择线路A，不行的话切换至线路B或者线路C）。部分地区像东三省如果线路A、B、C都连接不上，可尝试更改下手机里的网络接入点，把NET接入点更改到WAP接入点，具体更改的方法：找到手机自带的设置--移动数据--接入点，选择WAP接入点。</div><div><br><b>注意事项：</b></div><div>在连接软件的过程中，必须关掉无线网，切换至手机流量数据（大家不需要担心会消耗流量，启动自身数据的目的主要是运行流量软件软件，只有软件正常运行，上网的过程中才可以消耗软件里面的流量）</div><div>软件连接上之后，请先拨打1008611查询自己的流量剩余，先观看个2.3分钟的小视频（不要看时间久了，以免不兼容造成大量流量扣除），再查下自己的流量，如果自身流量在没有消耗的情况下，请继续测试。</div><div>本软件仅限于安卓移动和苹果移动4G用户使用。</div><div>本软件因手机品牌兼容性问题以及地区差异，节流比例略有不同。<br><br></div><div><b>后台运行注意：</b></div><div>有些人使用“流量软件”过一段时间会断开，可能被手机或者清理软件杀死后台。流量软件必须要后台运行，解决方法：</div><div><b>一：360卫士添加白名单</b></div><div>360卫士主页面―右上角人形图标―设置―清理加速―内存加速忽略名单―添加内存忽略名单―然后找到“流量软件”点添加</div><div><b>二：净化大师</b></div><div>净化大师主页面―右上角三个小点―进化设置―系统净化―找到“流量软件”点击―把防止开机和后台自启、智能回收后台进程分别关闭</div><div><b>三：猎豹清理大师</b></div><div>猎豹清理大师主页面―手机加速―右上角三个小点―进程白名单―加号―找到“流量软件”点击添加</div><div><b>四：手机管家<br></b>打开手机管家―右上角人形图标―设置―清理加速保护名单―添加―找到“流量软件”打对勾―确定</div><div><b>五：百度手机卫士添加白名单</b></div><div>百度手机卫士主页面―右上角人形图标―通用设置―手机加速白名单―添加白名单―找到“流量软件”点添加</div><div>类似的如果有其它清理软件，请把“流量软件”添加至白名单</div><div><br><b>常见问题解答</b><b>：</b></div><div>1，流量软件一直处于连接中，连接不上怎么办？</div><div>2，请关闭您的无线网，开启手机流量数据；</div><div>3，检查下您的移动4G信号是否稳定</div><div><br></div><div><b>登录时显示验证失败：</b></div><div>原因一：可能由于服务器连接过于频繁，请等待几分钟再次登录</div><div>原因二：请仔细检查下您的用户名，密码有没有输入正确，密码有没有点击保存。<br><br></div><div><b>使用流量软件可以分享热点吗？</b></div><div>此软件仅限于本手机自己使用，不支持热点分享，开启热点分享的客户，产生的流量费用由本人承担</div><div><br></div><div><b>如何判断流量软件是否连接正常？</b></div><div>在正常连接的情况下，绝大多数手机左上角会出现小钥匙图标或者VPN的图标，可通过下拉小钥匙VPN查看数据是否连接正常。</div><div><br></div><div><b>使用流量软件软件为什么会消耗本机流量？</b></div><div>原因一：流量软件在每次登陆或者连接时可能需要损耗50K左右手机套餐流量，手机自带的软件在后台运行会消耗少量流量。</div><div>原因二：在使用过程中如果遇到掉线又重新连接，请您在使用过程中经常检查软件是否正常连接。</div><div>原因三：流量软件在部分城市存在盲区包括个别手机品牌型号不能兼容导致不能节流，首次使用时一定要先做测试，确认节流后再继续使用。</div><div>原因四：每个地区所用线路选择不一样，在使用过程中发现不免流，可以尝试下切换线路或者手机网络接入点改为WAP接入点试一下。<br><br></div><div><b>流量软件为什么在使用的过程中会发生掉线？</b></div><div>原因一：拨打电话时，网络会自行中断，通话完之后部分手机需要手动重新连接软件。</div><div>原因二：手机4G信号不稳定，自动切换至2G网络或者无网络区域时会掉线，</div><div>原因三：部分手机自带一键清理功能，或者安装360，手机管家，手机助手等此类软件，请将流量软件设置为白名单，可以避免部分掉线问题</div><div>原因四：请不要随便恢复手机出厂设置，也不要随便清理手机数据，由此造成的损失自行承担。</div>
              
            </div>
          </div>
        </div>
      </div>      

    </div>
    
  </div>

<?php include("../user/js.php");?>

</body>
</html>