<?php

$mod='blank';
include("../api.inc.php");

$u = daddslashes($_GET['user']);
$p = daddslashes($_GET['pass']);
$res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
if(!$res){
//	header('location: login.php');
		exit("<script language='javascript'>alert('未正确登录，或用户名或密码不正确！');window.location.href='/user/login.php';</script>");
}

$tian=$res['tian'];

if($tian>0){

	/**
	 * PHP里的日期加减方法
	 */
	// 第一步，假设有一个时间
	$a = date('Y-m-d');
	 
	// 第二步，获得这个日期的时间戳
	$a_time = strtotime($a);
	 
	// 第三步，获得加五个月后的时间戳
	$b_time = strtotime('+'.$tian.' Day',$a_time);
	//echo "<script language='javascript'>alert('".$b_time."');</script>";

	/*$endtime = strtotime(time());*/
	$DB->query("update `openvpn` set `endtime`='$b_time',`i` ='1',`tian` ='0' where `iuser`='{$u}'");
	echo "<script language='javascript'>alert('您好，这是第一次登录，帐号已激活，使用天数为".$tian."天！');window.location.reload();</script>";

}


if($_POST['km']){
	$km = daddslashes($_POST['km']);
	$myrow=$DB->get_row("select * from auth_kms where kind=1 and km='$km' limit 1");
	if(!$myrow){
		exit("<script language='javascript'>alert('此激活码不存在');history.go(-1);</script>");
	}elseif($myrow['isuse']==1){
		exit("<script language='javascript'>alert('此激活码已被使用');history.go(-1);</script>");
	}else{
		//$duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
		$duetime = time() + $myrow['value']*24*60*60;

		$addll = $myrow['values']*1024*1024*1024;
		if($res['endtime'] < time()){//已到期
			$sql="update `openvpn` set `isent`='0',`irecv`='0',`maxll`='{$addll}',`endtime`='{$duetime}',`dlid`='{$myrow['daili']}',`i`='1' where `iuser`='{$u}' && `pass`='{$p}'";
			if($DB->query($sql)){
				$DB->query("update `auth_kms` set `isuse` ='1',`user` ='$u',`usetime` ='$date' where `id`='{$myrow['id']}'");
				wlog('账号激活','用户'.$u.'使用激活码'.$km.'开通账号['.$date.']');

				//赠送推荐人流量1
				$zrs=$DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}'");
				$tj_user=$zrs['tj_user'];
				$tj_ok=$zrs['tj_ok'];

				$zzrs=$DB->get_row("SELECT * FROM auth_config");
				$user_cash_con=$zzrs['user_cash'];
				//echo "<script language='javascript'>alert('推荐成功赠送流量：".$user_cash_con."');</script>";

				if($tj_ok>0){
					$tjr=$DB->get_row("SELECT * FROM openvpn where `iuser`='{$tj_user}'");
					$tj_new_maxll=round($tjr['maxll']+$user_cash_con);
					//echo "<script language='javascript'>alert('新流量".$tj_new_maxll."');</script>";

					$DB->query("update `openvpn` set `maxll`='$tj_new_maxll', `i`='1' where `iuser`='{$tj_user}'");
					$DB->query("update `openvpn` set `tj_ok` ='0' where `iuser`='{$u}'");
					echo "<script language='javascript'>alert('您的推荐人：".$tj_user."，获得".round($user_cash_con/1024/1024)."MB流量！');</script>";
					//echo "<script language='javascript'>alert('推荐人：".$tj_user."');</script>";
				}

				exit("<script language='javascript'>alert('开通成功！');history.go(-1);</script>");
			}else{
				exit("<script language='javascript'>alert('开通失败！');history.go(-1);</script>");
			}
		}else{
			$sql="update `openvpn` set `isent`='0',`irecv`='0',`maxll`='{$addll}',`endtime`='{$duetime}',`dlid`='{$myrow['daili']}',`i`='1' where `iuser`='{$u}' && `pass`='{$p}'";
			if($DB->query($sql)){
				$DB->query("update `auth_kms` set `isuse` ='1',`user` ='$u',`usetime` ='$date' where `id`='{$myrow['id']}'");
				wlog('账号充值','用户'.$u.'使用激活码'.$km.'续费账号['.$date.']');

				//赠送推荐人流量2
				$zrs=$DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}'");
				$tj_user=$zrs['tj_user'];
				$tj_ok=$zrs['tj_ok'];

				$zzrs=$DB->get_row("SELECT * FROM auth_config");
				$user_cash_con=$zzrs['user_cash'];
				//echo "<script language='javascript'>alert('推荐成功赠送流量：".$user_cash_con."');</script>";

				if($tj_ok>0){
					$tjr=$DB->get_row("SELECT * FROM openvpn where `iuser`='{$tj_user}'");
					$tj_new_maxll=round($tjr['maxll']+$user_cash_con);
					//echo "<script language='javascript'>alert('新流量".$tj_new_maxll."');</script>";

					$DB->query("update `openvpn` set `maxll`='$tj_new_maxll', `i`='1' where `iuser`='{$tj_user}'");
					$DB->query("update `openvpn` set `tj_ok` ='0' where `iuser`='{$u}'");
					echo "<script language='javascript'>alert('您的推荐人：".$tj_user."，获得".round($user_cash_con/1024/1024)."MB流量！');</script>";
					//echo "<script language='javascript'>alert('推荐人：".$tj_user."');</script>";
				}

				exit("<script language='javascript'>alert('续费成功！');history.go(-1);</script>");
			}else{
				exit("<script language='javascript'>alert('续费失败！');history.go(-1);</script>");
			}
		}
		//$duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
		//$addll = ($res['endtime'] < time() ? $myrow['values'] : $res['endtime']) + $myrow['values'];
		//$sql="update `openvpn` set `maxll`=`maxll` + '0',`endtime`='{$duetime}' where `iuser`='{$u}' && `pass`='{$p}'";
		
	}
	//if($DB->query("update `openvpn` set `pass`='$pass',`maxll`='$maxll',`i`='$state',`endtime`='$endtime' where iuser='$user'"))
}elseif($_POST['newpass']){
	$newpass = daddslashes($_POST['newpass']);
	if($DB->query("update `openvpn` set `pass` ='$newpass' where `iuser`='$u' && `pass`='$p' limit 1")){
		exit("<script language='javascript'>alert('密码修改成功！');history.go(-1);</script>");
	}else{
		exit("<script language='javascript'>alert('密码修改失败！');history.go(-1);</script>");
	}
}

/*签到*/
$qrs=$DB->get_row("SELECT * FROM auth_config");
$user_cash_con=$qrs['user_cash'];
$qian_con=$qrs['qian'];

if($_POST['qiandao']){

	$qian_num_con=1;
	//echo "<script language='javascript'>alert('签到赠送流量为：".$qian_con."');</script>";
	$qrs2=$DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}'");
	$now_time = date("Y-m-d");
	$qian_date = $qrs2['qian_date'];
	$qian_num = $qrs2['qian_num'];
	//echo "<script language='javascript'>alert('今天".$qian_date."');</script>";

	if($qian_date != $now_time){
		//echo "<script language='javascript'>alert('可以钱都');</script>";
		$new_maxll=round($qrs2['maxll']+$qian_con);
		$qian_num=round($qrs2['qian_num']+$qian_num_con);
		//echo "<script language='javascript'>alert('该用户的流量".$maxll."');</script>";
		//echo "<script language='javascript'>alert('更新的流量为".$maxll."');</script>";
		$DB->query("update `openvpn` set `maxll`='$new_maxll',`qian_date` ='$now_time',`qian_num` ='$qian_num' where `iuser`='{$u}'");
		echo "<script language='javascript'>alert('签到成功，新增".round($qian_con/1024/1024)."MB流量！');</script>";
	}else{
		echo "<script language='javascript'>alert('您今天已经签到了！');</script>";
	}

}else{
	
}



$title='用户中心';


$config = $DB->get_row("SELECT * FROM auth_config");
$gonggao=$config['ggs'];//公告获取

/*获取代理信息*/
$daili_info = $DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}'");
$daili_info_id=$daili_info['dlid'];
//echo "<script language='javascript'>alert('获取代理信息：".$daili_info_id."');</script>";

if($daili_info_id){
	$config_dl = $DB->get_row("SELECT * FROM auth_daili WHERE id='$daili_info_id' limit 1");
	$config_name=$config_dl['name'];//代理姓名
	$config_qq=$config_dl['qq'];
	$config_tel=$config_dl['tel'];
	$config_buy=$config_dl['buy'];//购买链接
	$config_buy2=$config_dl['buy2'];//购买代码
	//echo "<script language='javascript'>alert('获取代理信息：".$config_name."');</script>";
}else{
	$rs=$DB->get_row("SELECT * FROM website");
	$config_name=$rs['title'];
	$config_qq=$rs['qq'];
	$config_tel=$rs['tel'];

	$rs2=$DB->get_row("SELECT * FROM auth_config");
	$config_buy=$rs2['shopUrl'];
	$config_buy2=$rs2['shopCode'];
}

/*获取支付宝*/
$alpay= $DB->get_row("SELECT * FROM alipay");
$alpay_on=$alpay['partner'];

?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                         <br> <h1 class="widget-heading h3 text-black"><strong><?php echo "您好，".$res['iuser'];?>！<?=($res['i']?'</strong><div class="btn btn-success m-t-10">账号正常</div>':'<div class="btn btn-danger m-t-10">账号禁用</div>')?></h1>
                                             <br>
                                      </div>
									  
                                      
                                  </div>
                            </div>
					
					
					<div class="widget-content widget-content-mini themed-background-muted">
					<div class="row">
					<div class="col-sm-12 col-lg-6">
                                <a href="javascript:void(0)" class="widget">
                                    <div class="widget-content widget-content-mini themed-background-social">
                                        <span class="pull-right text-muted"><font><font></font></font></span>
                                        <strong class="text-light-op"><font><font></font></font></strong>
                                    </div>
                                    <div class="widget-content themed-background-social clearfix">
                                        <div class="widget-icon pull-right">
                                            <i class="gi gi-charts text-light-op"></i>
                                        </div>
                                        <h2 class="widget-heading h3 text-light"><strong><font><font><?php echo round($res['maxll']/1024/1024);?>MB</font></font></strong></h2>
                                        <span class="text-light-op"><font><font>总计流量</font></font></span>
                                    </div>
                                </a>
                            </div>
							
							
							
							<div class="col-sm-12 col-lg-6">
                                <a href="javascript:void(0)" class="widget">
                                    <div class="widget-content widget-content-mini themed-background-success">
                                        <span class="pull-right text-muted"><font><font></font></font></span>
                                        <strong class="text-light-op"><font><font></font></font></strong>
                                    </div>
                                    <div class="widget-content themed-background-success clearfix">
                                        <div class="widget-icon pull-right">
                                            <i class="gi gi-cloud-download text-light-op"></i>
                                        </div>
                                        <h2 class="widget-heading h3 text-light"><strong><font><font><?php echo round((($res['maxll']-$res['isent']-$res['irecv']))/1024/1024);?>MB</font></font></strong></h2>
                                        <span class="text-light-op"><font><font>剩余流量</font></font></span>
                                    </div>
                                </a>
                            </div>
				
				
                                  <div class="col-sm-12 col-lg-6" >
								<a href="javascript:void(0)" class="widget">
                                    <div class="widget-content widget-content-mini themed-background-info text-center text-light-op">
                                        <strong><font><font> 流量剩余比例
                                    </font></font></strong></div>
                                    <div class="widget-content themed-background-info">
									
                                        <div class="pie-chart easyPieChart text-light-op text-center" data-percent="</div>" data-line-width="3" data-bar-color="#cccccc" data-track-color="#f9f9f9" style="width: 80px; height: 80px; line-height: 80px;">
                                            <span><strong><font><font><?php echo round((($res['maxll']-$res['isent']-$res['irecv']))/$res['maxll']*100);?>％</font></font></strong></span>
                                        <canvas width="80" height="80"></canvas></div>
										
                                    </div>
                                    <div class="widget-content themed-background-info">
									<h5 class=" text-light-op text-center">已经上传：<?php echo round($res['irecv']/1024/1024);?>M | 已经下载：<?php echo round($res['isent']/1024/1024);?>M</h5>
                                        <div class="progress progress-striped progress-mini active remove-margin">
                                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo round((($res['maxll']-$res['isent']-$res['irecv']))/$res['maxll']*100);?>%"></div>
                                        </div>
                                    </div>
									</a>
                                </div>
			                    <div>	</div>
								<div class="col-sm-12 col-lg-6" >
								<a href="javascript:void(0)" class="widget">
								<?php
									date_default_timezone_set('Asia/Hong_Kong');
									$startDate = date('Y-m-d',$res['starttime']);
									$endDate = date('Y-m-d',$res['endtime']);
									 
									// 将日期转换为Unix时间戳
									$startDateStr = strtotime($startDate);
									$endtDateStr = strtotime($endDate);
									$total = $endtDateStr-$startDateStr;
									 
									$now = strtotime(date('Y-m-d'));
									$remain = $endtDateStr-$now;
									 
									//echo '为期：'.$total/(3600*24).'天<br>';
									//echo '剩余：'.$remain/(3600*24).'天';
	                            ?>
                                    <div class="widget-content widget-content-mini themed-background-danger text-center text-light-op">
                                        <strong><font><font> 流量剩余天数
                                    </font></font></strong></div>
                                    <div class="widget-content themed-background-danger">
									
                                        <div class="pie-chart easyPieChart text-light-op text-center" data-percent="</div>" data-line-width="3" data-bar-color="#cccccc" data-track-color="#f9f9f9" style="width: 80px; height: 80px; line-height: 80px;">
                                            <span><strong><font><font><?php echo $remain/(3600*24);?>天</font></font></strong></span>
                                        <canvas width="80" height="80"></canvas></div>
										
                                    </div>
                                    <div class="widget-content themed-background-danger">
									<h5 class=" text-light-op text-center">开通时间：<?php echo date('Y-m-d',$res['starttime']);?>| 到期时间：<?php echo date('Y-m-d',$res['endtime']);?></h5>
                                        <div class="progress progress-striped progress-mini active remove-margin">
                                            <div class="progress-bar progress-bar-info"  role="progressbar" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo round(($total/(3600*24))/($total/(3600*24))*100);?>%"></div>
                                        </div>
                                    </div>
									</a>
                                </div>
			
					
			

						
					</div>

			
			<div class="row">
				<div class="col-sm-12">
					<div class="panel panel-color panel-info"><!-- Add class "collapsed" to minimize the panel -->
						<div class="btn btn-info col-sm-12">
							<h3 class="panel-title text-center">卡密充值</h3>
							
							<div class="panel-options">
								
							</div>
						</div>
						
						<div class="panel-body">
					
                      <p><img border="0" width="32" >公告：<?php echo $gonggao;?> </p>
							<br>
							<form action="" method="POST" id="kmcz" role="form" class="validate">
								<div class="input-group">
									<input type="text" placeholder="请输入卡密" class="form-control no-right-border form-focus-info" id="km" name="km"  data-validate="required" data-message-required="请输入卡密信息">
									<span class="input-group-btn">
										<button class="btn btn-info" type="submit">马上充值</button>
									</span>
								</div>
							</form>
			
						</div>

					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-sm-12">
	                    <div class="panel panel-color panel-danger"><!-- Add class "collapsed" to minimize the panel -->
	                        <div class="btn btn-danger col-sm-12">
	                            <h3 class="panel-title text-center">在线充值</h3>
	                            
	                            <div class="panel-options">
	                                
	                            </div>
	                        </div>
	                        
	                        <div class="panel-body">
	                            
									<?php
										if($alpay_on<>""){
											
										}
										else{
											$hide1 = "hide";
										}
									?>
									<?php
										if($config_buy<>""){
											
										}
										else{
											$hide2 = "hide";
										}
									?>
									<?php
										if($config_buy2<>""){
											
										}
										else{
											$hide3 = "hide";
										}
									?>
									<div class="row">
									<br><br>
										<div class="col-sm-6">
		                                    <a href="buy.php?user=<?php echo $u?>&pass=<?php echo $p?>" class="btn btn-info btn-icon <?php echo $hide1?>">
		                                        <i class="fa-credit-card"></i>
		                                        <span>支付宝在线充值</span>
		                                    </a>
		                                    <a target="_blank" href="<?php echo $config_buy?>" class="btn btn-danger btn-icon <?php echo $hide2?>">
		                                        <i class="fa-link"></i>
		                                        <span>在线充值平台</span>
		                                    </a>
		                                </div>
		                                <div class="col-sm-6  <?php echo $hide3?>">
		                                	<?php echo $config_buy2?>
		                                </div>
	                                </div>
	            
	                        </div>

	                    </div>
				</div>
			</div>

			<div class="row text-center">
				<div class="col-sm-6">
					<form action="" method="POST" id="qiandao_f" role="form">
					<input type="hidden" name="qiandao" value="1"/>
					<button type="submit" class="btn btn-success btn-icon-standalone btn-block">
						
						<span style="
    padding-left: 35px;
">每日签到赠送<?php echo round($qian_con/1024/1024); ?>MB（已签到<?php
						$qqrs2=$DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}'");
						$qian_num2 = $qqrs2['qian_num'];
						 echo $qian_num2;
						 ?>次）</span>
					</button>
					</form>
				</div>
				<div class="col-sm-6">
					<a target="_blank" href="/user/reg.php?tj_user=<?php echo $res['iuser'];?>" class="btn btn-info btn-sm btn-icon-standalone btn-block">
						
						<span style="
    padding-left: 35px;
">推荐送<?php echo round($user_cash_con/1024/1024); ?>MB（新用户激活卡密即可）</span>
					</a>
				</div>
			</div>
			</div>
					
					
					
					
					
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	<body>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>