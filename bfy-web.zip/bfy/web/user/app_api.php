

<?php
include "../api.inc.php";

class Response {
    public static function json($code, $msg, $data = NULL) {
        $res = array("code" => $code, "msg" => $msg, "data" => $data);
        echo json_encode($res);
        exit();
    }
}
$key = daddslashes($_GET['token']);
$res = $DB->get_row("SELECT * FROM `bfy_token` where 1 limit 1");
if ($res["token"] != $key) {
    Response::json(1, "缤纷云提示您接口错误！");
} else {
    if ($_GET["c"] == "Appurl") {
        $rs = $DB->query("SELECT * FROM bfy_link ORDER BY sortby ASC,id DESC");
        while ($res = $DB->fetch($rs)) {
            $rows[] = $res;
        }
        Response::json(1, $rows);
    }
    if ($_GET["c"] == "LinesCata") {
        $rs = $DB->query("SELECT * FROM `bfy_grop` where 1 ORDER BY id asc");
        while ($res = $DB->fetch($rs)) {
            $rows[] = $res;
        }
        Response::json(1, $rows);
    }
    if ($_GET["c"] == "Lines") {
        if (isset($_GET['cid'])) {
            $cid = intval($_GET['cid']);
            $rs = $DB->query("SELECT * FROM `open` WHERE type=$cid order by id desc");
            while ($res = $DB->fetch($rs)) {
                $rows[] = $res;
            }
            Response::json(1, $rows);
        }
    }
}
?>
