
<?php
/**
 * 注册
**/
$mod='blank';
include("../api.inc.php");
$dlconfig=$DB->get_row("SELECT * FROM auth_config WHERE 1");
$tj_user=$_REQUEST['tj_user'];
$dl=$_REQUEST['dl'];
if($dl){
}else{
	$dl='0';
}
if($_POST['user'] && $_POST['pass']){
	$user=daddslashes($_POST['user']);
	$pass=daddslashes($_POST['pass']);
	$dlid=daddslashes($_POST['dlid']);
	$fwq=daddslashes($_POST['fwq']);

	if($fwq){
	}else{
		$fwq='0';
	}

	$verifycode=daddslashes($_POST['verifycode']);
	$row = $DB->get_row("SELECT * FROM `openvpn` WHERE `iuser`='$user' limit 1");

	$i=0;
	$b_time =time();

	//赠送新注册用户流量
	$rs=$DB->get_row("SELECT * FROM auth_config");
	$reg_cash_con=$rs['reg_cash'];
	$user_endtime_con=$rs['user_endtime'];

	if($reg_cash_con>0){
		$i=1;
		/**
		 * PHP里的日期加减方法
		 */
		// 第一步，假设有一个时间
		$a = date('Y-m-d');
		 
		// 第二步，获得这个日期的时间戳
		$a_time = strtotime($a);
		 
		// 第三步，获得加五个月后的时间戳
		$b_time = strtotime('+'.$user_endtime_con.' Day',$a_time);
		//echo "<script language='javascript'>alert('".$b_time."');</script>";
		 
		// 第四部，把时间戳转换回日期格式
		//$b = date('Y-m-d H:i:s',$b_time);
		//echo '这是加了3天后的日期'.$b;
		
	}


	//记录赠送流量给推荐人
	$tj_user=$_REQUEST['tj_user_c'];
	$zrs=$DB->get_row("SELECT * FROM auth_config");
	$user_cash_con=round($zrs['user_cash']/1024/1024);
	if($tj_user){
		$tj_ok=1;
		//echo "<script language='javascript'>alert('推荐人：".$tj_user."');</script>";
	}

	if(!is_username($user)){
		exit("<script language='javascript'>alert('用户名只能是2~20位的字母数字！');history.go(-1);</script>");
	}elseif($row){
		exit("<script language='javascript'>alert('用户名已被使用！');history.go(-1);</script>");
	}elseif(!$verifycode || $verifycode!=$_SESSION['verifycode']){
			exit("<script language='javascript'>alert('验证码不正确！');history.go(-1);</script>");
	}else{
		//$DB->query("insert `openvpn`(`iuser`,`pass`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`,`fwqid`) values('{$user}','{$pass}',0,0,0,0,'".time()."','".time()."','".$fwq."')");
		$DB->query("insert `openvpn`(`iuser`,`pass`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`,`fwqid`,`tj_user`,`tj_ok`,`dlid`) values('{$user}','{$pass}',0,0,'{$reg_cash_con}','$i','".time()."','".$b_time."','".$fwq."','".$tj_user."','".$tj_ok."','".$dlid."')");
		$row = $DB->get_row("SELECT * FROM `openvpn` WHERE `iuser`='$user' limit 1");
		if($row['id']){
			unset($_SESSION['verifycode']);
			exit("<script language='javascript'>alert('注册成功，请您下载APP！');window.location.href='/user/app.php?dl=".$dl."&user=".$user."&pass=".$pass."';</script>");
		}else{
			exit("<script language='javascript'>alert('注册失败，请联系管理员！');history.go(-1);</script>");
		}
	}
}

$fwqlist=$DB->query("SELECT * FROM auth_fwq");

$title='用户注册';
?>
<!doctype html>
<html lang="zh">
<head>
<?php
$rs=$DB->get_row("SELECT * FROM website");

$webtitle=$rs['title'];


?>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
<meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title><?php echo $webtitle ?> - <?php echo $title ?></title>
<link rel="stylesheet" type="text/css" href="../asset/login/styles.css">
</head>
<body  class="htmleaf-container">
<div class="htmleaf-container">
<script type="text/javascript">
					jQuery(document).ready(function($)
					{
						// Reveal Login form
						setTimeout(function(){ $(".fade-in-effect").addClass('in'); }, 1);
						
						
						// Validation and Ajax action
						$("form#login").validate({
							rules: {
								user: {
									required: true
								},
								
								pass: {
									required: true
								},
								
								verifycode: {
									required: true
								}
							},
							
							messages: {
								user: {
									required: '此为必填项！'
								},
								
								pass: {
									required: '此为必填项！'
								},
								
								verifycode: {
									required: '请填写！'
								}
							},
							
						});
						
						// Set Form focus
						$("form#login .form-group:has(.form-control):first .form-control").focus();
					});
				</script>
				

	<div class="wrapper">
		<div class="container">
		<form action="./reg.php?tj_user_c=<?php echo $tj_user;?>&dl=<?php echo $dl;?>" method="post" role="form" id="login" class="login-form fade-in-effect">
				<b><h2><?php echo $webtitle ?> - <?php echo $title ?></h2><br></b>
			<form class="form">
				<input type="text" name="user" id="user" autocomplete="off" placeholder="帐号">
				<input type="password" name="pass" id="pass" autocomplete="off" placeholder="密码">
				<div class="form-group">
						<br><label class="control-label">Simple select</label>
						
						<script type="text/javascript">
							jQuery(document).ready(function($)
							{
								$("#sboxit-1").selectBoxIt().on('open', function()
								{
									// Adding Custom Scrollbar
									$(this).data('selectBoxSelectBoxIt').list.perfectScrollbar();
								});
							});
						</script>
						
						<select class="form-control" id="sboxit-1" name="fwq">
							<?php while($v = $DB->fetch($fwqlist)): ?>
							<option value="<?php echo $v['id']; ?>"><?php echo $v['name']; ?></option>
							<?php endwhile; ?>
						</select>
							
					</div>
					<div class="form-group">
		            	<br><label class="control-label" for="verifycode">验证码</label>
		            	<input type="text" id="verifycode" name="verifycode" class="form-control" placeholder="验证码" required="required" style="max-width: 65%;display:inline-block;"/>&nbsp;<img title="点击刷新" src="../verifycode.php" onclick="this.src='../verifycode.php?'+Math.random();" style="max-height:32px;vertical-align:middle;" class="img-rounded">
		            </div>
				 
				<button type="submit">注册</button>
				
				<div class="external-login">
					<br><a href="login.php" class="btn btn-info text-center">
						<i class="fa-edit"></i>
						已经有账号？立即登录吧！
					</a>
				
			</form>
			
		</div>
		
		<ul class="bg-bubbles">
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
		</ul>
	</div>
</div>
<script src="../asset/login/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
$('#login-button').click(function (event) {
	
	
		event.preventDefault();
		$('form').fadeOut(500);
		$('.wrapper').addClass('form-success');
		
	

});
</script>

</body>
</html>
