<?php
$mod='blank';
include("../api.inc.php");

$u = daddslashes($_GET['user']);
$p = daddslashes($_GET['pass']);
$res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
if(!$res){
//	header('location: login.php');
		exit("<script language='javascript'>alert('未正确登录，或用户名或密码不正确！');window.location.href='/user/login.php';</script>");
}

/*获取代理信息*/
$daili_info = $DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}'");
$daili_info_id=$daili_info['dlid'];
if($daili_info_id){
	
}else{
	$daili_info_id=0;
}
//echo "<script language='javascript'>alert('获取代理信息：".$daili_info_id."');</script>";

if($daili_info_id){
	$config_dl = $DB->get_row("SELECT * FROM auth_daili WHERE id='$daili_info_id' limit 1");
	$config_name=$config_dl['name'];//代理姓名
	$config_qq=$config_dl['qq'];
	$config_tel=$config_dl['tel'];
	$config_buy=$config_dl['buy'];//购买链接
	$config_buy2=$config_dl['buy2'];//购买代码
	//echo "<script language='javascript'>alert('获取代理信息：".$config_name."');</script>";
}else{
	$rs=$DB->get_row("SELECT * FROM website");
	$config_name=$rs['title'];
	$config_qq=$rs['qq'];
	$config_tel=$rs['tel'];

	$rs2=$DB->get_row("SELECT * FROM auth_config");
	$config_buy=$rs2['shopUrl'];
	$config_buy2=$rs2['shopCode'];
}


?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                         <br> <h1 class="widget-heading h3 text-black"><strong><?php echo "您好，".$res['iuser'];?>！<?=($res['i']?'</strong><div class="btn btn-success m-t-10">账号正常</div>':'<div class="btn btn-danger m-t-10">账号禁用</div>')?></h1>
                                             <br>
                                      </div> 
                                  </div>
                            </div>
							
					
			
					
					
					
					<div class="row">
					
					<a href="javascript:void(0)" class="widget">
					
                                            <div id="wap" class="col-sm-12">
											<div class="widget-content themed-background-social clearfix">
											
                                            <div class="alert alert-white">
                                                
                                                
                                                <strong>部分线路需要WAP模式：</strong> <br>安卓从网络设置APN接入点切换，苹果用户使用IOS系统自带的Safari浏览器打开下方链接，会自动下载描述文件，点击安装，然后重启手机。<hr>

                                                <div class="col-xs-12">                 
                                                    <button href="ios/CMWAP.mobileconfig" class="btn btn-primary"><i class="fa fa-cloud-download"></i> 移动wap</button>
													<button href="ios/3GWAP.mobileconfig" class="btn btn-info"><i class="fa fa-cloud-download"></i> 联通wap</button>
													<button href="ios/CTWAP.mobileconfig" class="btn btn-success"><i class="fa fa-cloud-download"></i> 电信wap</button>
													
                                                </div>
                                            </div>
                                            </div></div>
											</a>
											
											
											
											
											
											
											
		        
					
					
					<div class="  block full">
					
                                    <!-- Block Tabs Title -->
                                    <div class="block-title ">
                                        
                                        <ul class="nav nav-tabs " data-toggle="tabs">
                                            <li class="col-xs-4"><a href="#block-tabs-home">移动</a></li>
                                            <li class="col-xs-4"><a href="#block-tabs-profile">联通</a></li>
											<li class="col-xs-4"><a href="#block-tabs-settings">电信</a></li>
                                             </ul>
                                    </div>
                                    <!-- END Block Tabs Title -->

                                    <!-- Tabs Content -->
                                    <div class="block full tab-content widget-content widget-content-full" style="height: 480px; overflow: auto;">
                                        <div class="tab-pane" id="block-tabs-home"><table class="table table-striped table-borderless remove-margin">
			
              <tbody >
<?php
$res=$DB->query("SELECT * FROM `open` WHERE  `type` = 1 ");
while($open = $DB->fetch($res)){
echo '
                <tr>
                  <td class="middle-align"style="width: 40px;">';
                  echo $open['name'];
     echo   '</td>
                  <td style="text-align: right;">
                    <a href="/admin/down.php?id=';
    echo $open['id'];
    echo '" class="btn btn-info btn-single btn-sm" onclick="return confirm(\'请您使用OpenVPN打开该文件\');">安装</a>
                  </td>
                </tr>';
}
?>
              </tbody>
			  
            </table></div>
                                        <div class="tab-pane active" id="block-tabs-profile"><table class="table">
              <tbody>
<?php
$res=$DB->query("SELECT * FROM `open` WHERE  `type` = 2 ");
while($open = $DB->fetch($res)){
echo '
                <tr>
                  <td class="middle-align"style="width: 40px;">';
                  echo $open['name'];
     echo   '</td>
                  <td style="text-align: right;">
                    <a href="/admin/down.php?id=';
    echo $open['id'];
    echo '" class="btn btn-info btn-single btn-sm" onclick="return confirm(\'请您使用OpenVPN打开该文件\');">安装</a>
                  </td>
                </tr>';
}
?>
              </tbody>
            </table></div>
                                        <div class="tab-pane" id="block-tabs-settings"><table class="table">
              <tbody>
			  
<?php
$res=$DB->query("SELECT * FROM `open` WHERE  `type` = 3 ");
while($open = $DB->fetch($res)){
echo '
                <tr>
                  <td class="middle-align"style="width: 40px;">';
                  echo $open['name'];
     echo   '</td>
                  <td style="text-align: right;">
                    <a href="/admin/down.php?id=';
    echo $open['id'];
    echo '" class="btn btn-info btn-single btn-sm" onclick="return confirm(\'请您使用OpenVPN打开该文件\');">安装</a>
                  </td>
                </tr>';
}
?>
              </tbody>
			  
			  
			  
			  
			  </div>
                                    </div>
                                    <!-- END Tabs Content -->
                                </div>
					
					
					
					
					      </div>
					</div>
				</div>
			</div>
		</div>
	<body>
	<link rel="stylesheet" href="app/css/app.css"/>
    
    <script type="text/javascript">
    var is_weixin = (function() {
        var ua = navigator.userAgent.toLowerCase();
        if (ua.match(/MicroMessenger/i) == "micromessenger") {
            return true;
        } else {
            return false;
        }
    })();
    window.onload = function(){
        var winHeight = typeof window.innerHeight != 'undefined' ? window.innerHeight : document.documentElement.clientHeight;
        var btn = document.getElementById('J_weixin');
        var tip = document.getElementById('weixin-tip');
        var close = document.getElementById('close');
        if(is_weixin){
                tip.style.height = winHeight + 'px';
                tip.style.display = 'block';
                return false;
        }
    }
    

    </script>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>