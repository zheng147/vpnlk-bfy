<?php
$mod='blank';
include("../api.inc.php");

$user=$_REQUEST['user'];
$pass=$_REQUEST['pass'];

/*获取代理信息*/
$daili_info_id=$_REQUEST['dl'];
if($daili_info_id){
	
}else{
	$daili_info_id=0;
}

$name = $daili_info_id;
  if($name){
  }else{
    $name=dmg;
  }

$rs=$DB->get_row("SELECT * FROM website where daili = '$name'");
$logo=$rs['logo'];
$webtitle=$rs['title'];
$qq=$rs['qq'];
$app1=$rs['app1'];
$app2=$rs['app2'];
$ipinfo=$rs['ipinfo'];
$appleid1=$rs['appleid1'];
$appleps1=$rs['appleps1'];
$appleid2=$rs['appleid2'];
$appleps2=$rs['appleps2'];
$appleid3=$rs['appleid3'];
$appleps3=$rs['appleps3'];
$and_img1=$rs['and_img1'];
$and_img2=$rs['and_img2'];
$and_img3=$rs['and_img3'];
$and_img4=$rs['and_img4'];
$jia1=$rs['jia1'];
$jia2=$rs['jia2'];
$jia3=$rs['jia3'];
$jia4=$rs['jia4'];
$daili=$rs['daili'];
$webname=$rs['name'];

$bn=$DB->get_row("SELECT * FROM banner");
$img1=$bn['img1'];
$tit1=$bn['tit1'];
$info1=$bn['info1'];
$img2=$bn['img2'];
$tit2=$bn['tit2'];
$info2=$bn['info2'];
$img3=$bn['img3'];
$tit3=$bn['tit3'];
$info3=$bn['info3'];

    //赠送新注册用户流量
    $rs=$DB->get_row("SELECT * FROM auth_config");
    $reg_cash_con=round($rs['reg_cash']/1024/1024)."MB";
    $user_endtime_con =$rs['user_endtime'];

?>
<!DOCTYPE html>
<html lang="zh_CN">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<meta name="renderer" content="webkit">
  	<link rel="stylesheet" href="app/css/index.css"/><link rel="stylesheet" href="app/css/app.css"/>
	<title>请您下载APP软件进行使用流量</title>
</head>
<body class="success">
	<div class="page-wrap">
		<div class="info">
			<div class="ok-btn"><img src="app/img/ok.png" alt="注册成功"></div>
			<p class="entry-con">感谢您加入<?php echo $webtitle ?></p>
			<h2 class="entry-hd">恭喜您找到超实惠流量的方法</h2>
			<ul class="info-list">
				<li>您的账号：<?php echo $user ?></li>
				<li>您的密码：<?php echo $pass ?></li>
			</ul>
		</div>
		<div class="download">
			<h3 class="entry-hd">立即下载<?php echo $webtitle ?>软件</h3>
			<p class="entry-con">请选择您对应操作系统进行安装</p>
			<div class="download-btn"><a href="/web/ios.php?name=<?php echo $webname ?>"><img src="app/img/ios-btn.png" alt="苹果版下载"></a><a href="<?php echo $app1 ?>" class="android-btn" id="J_weixin"><img src="app/img/android-btn.png" alt="安卓版下载"></a></div>
		</div>
		<div class="app">
			<img src="app/img/app.jpg" alt="应用预览">
			<p class="entry-con">下载完成后，登录帐号后，点击“线路安装”<br/>根据您的区域测试线路是否免流<br/>如有下载困难，请联系QQ：<?php echo $qq ?></p>
		</div>
		<div class="footer-bg">
			<p class="entry-con">注：微信用户请在右上角选择“在浏览器中打开”，再选择下载应用</p>
		</div>
	</div>
	<div id="weixin-tip"><p><img src="app/img/live_weixin.png" alt="微信打开"/><span id="close" title="关闭" class="close">×</span></p></div>
	<script type="text/javascript">
	var is_weixin = (function() {
	    var ua = navigator.userAgent.toLowerCase();
	    if (ua.match(/MicroMessenger/i) == "micromessenger") {
	        return true;
	    } else {
	        return false;
	    }
	})();
	window.onload = function(){
		var winHeight = typeof window.innerHeight != 'undefined' ? window.innerHeight : document.documentElement.clientHeight;
		var btn = document.getElementById('J_weixin');
		var tip = document.getElementById('weixin-tip');
		var close = document.getElementById('close');
		if(is_weixin){
			btn.onclick = function(e){
				tip.style.height = winHeight + 'px';
				tip.style.display = 'block';
				return false;
			}
			close.onclick = function(){
				tip.style.display = 'none';
			}
		}
	}
	

	</script>
</body>
</html>