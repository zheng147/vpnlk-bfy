
<?php

/**
 * 登录
**/
$mod='blank';
include("../api.inc.php");
$title='用户登录';

?>
<!doctype html>
<html lang="zh">
<head>
<?php
$rs=$DB->get_row("SELECT * FROM website");

$webtitle=$rs['title'];


?>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
<meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title><?php echo $webtitle ?> - <?php echo $title ?></title>
<link rel="stylesheet" type="text/css" href="../asset/login/styles.css">
</head>
<body  class="htmleaf-container">
<div class="htmleaf-container">

	<div class="wrapper">
		<div class="container">
		<form action="index.php" method="get" role="form" id="login" class="login-form fade-in-effect">
				<b><h2><?php echo $webtitle ?> - <?php echo $title ?></h2><br></b>
			<form class="form">
				<input type="text" name="user" id="user" autocomplete="off" placeholder="帐号">
				<input type="password" name="pass" id="pass" autocomplete="off" placeholder="密码">
				 
				<button type="submit">登录</button>
				
				<div class="form-group">
				<a href="reg.php">
					<br/><button type="button" class="btn btn-default btn-lg btn-block btn-icon icon-left facebook-button">
						没有账号？立即注册
						<i class="entypo-user-add"></i>
					</button>
					</a>
				</div>
				
			</form>
			
		</div>
		
		<ul class="bg-bubbles">
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
		</ul>
	</div>
</div>
<script src="../asset/login/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
$('#login-button').click(function (event) {
	
	
		event.preventDefault();
		$('form').fadeOut(500);
		$('.wrapper').addClass('form-success');
		
	

});
</script>

</body>
</html>
