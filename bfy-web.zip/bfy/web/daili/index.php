<?php
$mod='blank';
include("../api.inc.php");
$title='代理中心';
$dlid=$_SESSION['dlid'];
$row = $DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$rs=$DB->get_row("SELECT * FROM auth_config WHERE 1");
$vip=$row['vip'];
$rmb=$row['rmb'];
$income=$row['income'];
if($vip==1){
    $dljg=$rs['dl1'];
    $dljgs=$rs['dls1'];
    $wx=$rs['wx1'];
    $v="<font>铜牌代理</font>";
}elseif($vip==2){
    $dljg=$rs['dl2'];
    $dljgs=$rs['dls2'];
    $wx=$rs['wx2'];
    $v="<font>银牌代理</font>";
}elseif($vip==3){
    $dljg=$rs['dl3'];
    $dljgs=$rs['dls3'];
    $wx=$rs['wx3'];
    $v="<font>金牌代理</font>";
}elseif($vip==0){
    $dljg=$rs['dl0'];
    $dljgs=$rs['dls0'];
    $wx=$rs['wx0'];
    $v="<font>普通代理</font>";
    //exit("<script language='javascript'>window.location.href='./login.php';</script>");
}elseif($vip==4){
    $dljg=$rs['dl4'];
    $dljgs=$rs['dls4'];
    $wx=$rs['wx4'];
        $v="<font>钻石代理</font>";
}elseif($vip==5){
    $dljg=$rs['dl5'];
    $dljgs=$rs['dls5'];
    $wx=$rs['wx5'];
    $v="<font>至尊代理</font>";
}
//$v="<font color='red'>VIP$vip</font>";
$config = $DB->get_row("SELECT * FROM auth_config");
$gonggao=$config['gg'];//公告获取
$shopUrl=$config['shopUrl'];//购买链接
$shopCode=$config['shopCode'];//购买链接
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

if($_POST['pass'] && $_POST['newpass']){
    $pass = daddslashes($_POST['pass']);
    $newpass = daddslashes($_POST['newpass']);
    if($DB->query("update `auth_daili` set `pass` ='$newpass' where `id`='$dlid' and `pass`='$pass' limit 1")){
        exit("<script language='javascript'>alert('密码修改成功！');history.go(-1);</script>");
    }else{
        exit("<script language='javascript'>alert('密码修改失败！');history.go(-1);</script>");
    }
}
//卡密
$rmb=$row['rmb'];
if($_GET['do']=="cz"){
$km = daddslashes($_POST['km']);
$kmrow = $DB->get_row("SELECT * FROM auth_kms WHERE km='{$km}' and kind=2 limit 1");    
if(!$kmrow){
    exit("<script>alert('卡密不存在');window.location.href='/daili';</script>");
    }elseif($kmrow['isuse']>0){
        exit("<script>alert('卡密已被使用');window.location.href='/daili';</script>");
    }else{
        $value = $kmrow['value'];
        $now_rmb = $rmb + $value;
        $DB->query("UPDATE auth_daili SET rmb='{$now_rmb}' WHERE id='{$dlid}'");
        $DB->query("UPDATE auth_kms SET isuse=1,usetime='".date("Y-m-d H:i:s")."',user='{$row['user']}' WHERE km='{$km}' and kind=2");
        //JXL_add for 2016-04-16 begin
        if($row['tj_user']){
            $rmb2=$value*$conf_rate;
            $sql2=$DB->query("update `auth_daili` set `tj_rmb`=`tj_rmb`+{$rmb2} where `user`='{$row['tj_user']}'");
        }
        //JXL_add for 2016-04-16 end
        wlog('代理充值','代理'.$row['user'].'使用卡密'.$km.'充值'.$value.'元['.$date.']');
        exit("<script>alert('成功充值".$value."元');window.location.href='/daili';</script>");
    }
}

//统计
$count=$DB->count("SELECT count(*) from `openvpn` WHERE dlid='$dlid'");
$count2=$DB->count("SELECT count(*) from `openvpn` WHERE i=0 and  dlid='$dlid'");
$countkm=$DB->count("SELECT count(*) from `auth_kms` WHERE daili='$dlid'");
$countkm2=$DB->count("SELECT count(*) from `auth_kms` WHERE isuse=0 and daili='$dlid'");
//echo "<script language='javascript'>alert('推荐人：".$countkm."');</script>";

/*获取支付宝*/
$alpay= $DB->get_row("SELECT * FROM alipay");
$alpay_on=$alpay['partner'];
?>
<!DOCTYPE html>
<html lang="en">

<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12"><br>
                                          <h1 class="widget-heading h3 text-black"><strong>您好，代理<?php
$drs=$DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$user2=$drs['user'];
                             echo $user2;?>！<span class="label label-primary"><?php echo $v;?></span></strong></h1><br>
                                              
                                         
                                      </div>
									  
                                      
                                  </div>
                            </div>
	
	<div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->
			
	
	
			<div class="row">
			<div class="col-sm-6 col-lg-6">
                                <a href="javascript:void(0)" class="widget">
                                    <div class="widget-content widget-content-mini text-right clearfix">
                                        <div class="widget-icon pull-left themed-background">
                                            <i class="gi gi-cardio text-light-op"></i>
                                        </div>
                                        <h2 class="widget-heading h3">
                                            <strong><span data-toggle="counter" data-to="<?php echo $count?>"></span></strong>
                                        </h2>
                                        <span class="text-muted">已注册帐号数量</span>
										<p><?php echo $count2?>个帐号已停用</p>
                                    </div>
									
                                </a>
                            </div>
                            <div class="col-sm-6 col-lg-6">
                                <a href="javascript:void(0)" class="widget">
                                    <div class="widget-content widget-content-mini text-right clearfix">
                                        <div class="widget-icon pull-left themed-background-success">
                                            <i class="gi gi-user text-light-op"></i>
                                        </div>
                                        <h2 class="widget-heading h3 text-success">
                                            <strong><span data-toggle="counter" data-to="<?php echo $countkm?>"></span></strong>
                                        </h2>
                                        <span class="text-muted">已生成卡密</span>
										<p><?php echo $countkm2?>个卡密未使用</p>
                                    </div>
									
                                </a>
                            </div>
			
			
			
			

			

			
			</div>

			
			
		


			<div class="row">
			<div class="col-sm-6">
			
						<div class="panel panel-default">
						
							<div class="themed-background-dark  panel-heading">
								<div class="text-muted">您的信息</div>
		
								<div class="panel-options">
									<a href="#sample-modal" data-toggle="modal" data-target="#sample-modal-dialog-1" class="bg"><i class="entypo-cog"></i></a>
									<a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
									<a href="#" data-rel="reload"><i class="entypo-arrows-ccw"></i></a>
									<a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
								</div>
							</div>
							<table class="table table-bordered table-responsive">

		
								<tbody>
									<tr>

										<td>代理ID：</td>
										<td><span class="label label-default"><?php echo $_SESSION['dlid'];?></span></td>

									</tr>
		
									<tr>

										<td>代理VIP等级：</td>
										<td><span class="label label-primary"><?php echo $v;?></span></td>

									</tr>
		
									<tr>

										<td>代理拿货价格：</td>
										<td><span class="label label-success"><?php echo "".$wx."元/无限";?></span>
                                            <span class="label label-success"><?php echo $dljg."元/天 + ".$dljgs."元/GB";?></span></td>

									</tr>
									
									<tr>

										<td>账户余额：</td>
										<td><span class="label label-warning"><?php echo $rmb."元";?></span></td>

									</tr>
									
									<tr>

										<td>推荐余额：</td>
										<td><span class="label label-danger"><?php echo $row['tj_rmb'];?></span></td>

									</tr>
									<tr>

										<td>推荐链接：</td>
										<td><a href="sale.php" target="_blank"><span class="label label-info ">点击这里</span></a></td>

									</tr>
		
								</tbody>
							</table>
							
						</div>
						<div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert">
                            <span aria-hidden="true">×</span>
                            <span class="sr-only">Close</span>
                        </button>
                        
                        <strong>管理员公告:</strong><br><?php echo $gonggao;?>
                    </div>
		
					</div>
				<div class="col-sm-6">
					<div class="panel panel-color panel-info"><!-- Add class "collapsed" to minimize the panel -->
						<div class="panel-heading themed-background-info">
							<h3 class="panel-title">卡密充值</h3>
                            
                            <div class="panel-options">
                                <a href="#" data-toggle="panel">
                                    
                                </a>
                            </div>
                        </div>
                        
                        <div class="panel-body">
                            
                            <p>如需购买卡密请联系管理员</p>
                            <br>
                            <form action="?do=cz" method="POST" class="validate">
                                <div class="input-group">
                                    <input type="text" placeholder="请输入卡密" class="form-control no-right-border form-focus-info" id="km" name="km" data-validate="required" data-message-required="请输入卡密信息">
                                    <span class="input-group-btn">
                                        <button class="btn btn-info" type="submit">马上充值</button>
                                    </span>
                                </div>
                            </form>
            
                        </div>

                    </div>
					<div class="row">
				<div class="col-sm-12">
	                    <div class="panel panel-color panel-danger"><!-- Add class "collapsed" to minimize the panel -->
	                        <div class="panel-heading themed-background-passion">
	                            <h3 class="panel-title text-success">在线充值</h3>
                            
                            <div class="panel-options">
                                <a href="#" data-toggle="panel">
                                    
                                </a>
                            </div>
                        </div>
                        
                        <div class="panel-body">
                            <?php
                                if($alpay_on<>""){
                                    
                                }
                                else{
                                    $hide1 = "hide";
                                }
                            ?>
                            <?php
                                if($shopUrl<>""){
                                    
                                }
                                else{
                                    $hide2 = "hide";
                                }
                            ?>
                            <?php
                                if($shopCode<>""){
                                    
                                }
                                else{
                                    $hide3 = "hide";
                                }
                            ?>
                            <div class="row">
                                <div class="col-sm-12">
                                    
									<button target="_blank" href="pay.php" class="btn btn-info <?php echo $hide1?>"><i class="fa fa-plus"></i> 支付宝在线充值</button>
									<button target="_blank" href="<?php echo $shopUrl?>" class="btn btn-success"><i class="fa fa-plus"></i> 在线充值平台</button>
                                      
                                </div>
                               
                            </div>
            
                        </div>

                    </div>
                </div>
            </div>
                              
                    

                </div>
            </div>

 
	          

            </div>
				</div>
			</div>
		</div>
	 <script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
    </body>
</html>