<?php
/**
 * 广告
**/
$mod='blank';
include("../api.inc.php");
$title='搜索卡密';

$dl=$_REQUEST['dl'];
if($dl){
}else{
    $dl='0';
}

$rs=$DB->get_row("SELECT * FROM auth_daili WHERE id='$dl' limit 1");
$dl_id=$rs['id'];
$user=$rs['user'];
$adtext=$rs['adtext'];
$adimg=$rs['adimg'];
$qq=$rs['qq'];
if($adimg<>""){
    
}
else{
    $adimg = "/other/ad.jpg";
}

?>
<!DOCTYPE html>
<html lang="en">

<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div class="light">
        <div class="ad_title">
            <?php echo $adtext; ?>
        </div>
       <br><br><br><br><br><br>
        <div class="row">
            <a href="/user/reg.php?dl=<?php echo $dl_id;?>" class="btn btn-purple btn-icon btn-icon-success btn-block">
                
                <span>马上注册流量任意玩</span>
            </a>
            <a href="mqqwpa://im/chat?chat_type=wpa&uin=<?php echo $qq; ?>&version=1&src_type=web&web_src=oicqzone.com" class="btn btn-info btn-icon btn-icon-info btn-block">
               
                <span>马上在线客服QQ</span>
            </a>
        </div><br><br>
        <div class="row text-center text-light">
            <div id="qrcode"></div>
            <span>手机扫码立即注册</span>
            <br><br>
        </div>
    </div>
	 <script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>
<script type="text/javascript" src="/asset/js/jquery.qrcode.min.js"></script>
<script>
jQuery('#qrcode').qrcode({
        render      : "canvas",//也可以替换为table
        width   : 150,
        height  : 150,
        text      : "http://<?php echo $_SERVER['HTTP_HOST'];?>/user/reg.php?dl=<?php echo $dl_id;?>"
});
</script>
        <!-- Load and execute javascript code used only in this page -->
        
    </body>
</html>