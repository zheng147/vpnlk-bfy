<?php
$mod='blank';
include("../api.inc.php");
$title='代理中心';
$dlid=$_SESSION['dlid'];
$row = $DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$rs=$DB->get_row("SELECT * FROM auth_config WHERE 1");
$vip=$row['vip'];
$rmb=$row['rmb'];
if($vip==1){
    $dljg=$rs['dl1'];
    $dljgs=$rs['dls1'];
    $v="<font>铜牌代理</font>";
}elseif($vip==2){
    $dljg=$rs['dl2'];
    $dljgs=$rs['dls2'];
    $v="<font>银牌代理</font>";
}elseif($vip==3){
    $dljg=$rs['dl3'];
    $dljgs=$rs['dls3'];
    $v="<font>金牌代理</font>";
}elseif($vip==0){
    $dljg=$rs['dl0'];
    $dljgs=$rs['dls0'];
    $v="<font>普通代理</font>";
    //exit("<script language='javascript'>window.location.href='./login.php';</script>");
}elseif($vip==4){
    $dljg=$rs['dl4'];
    $dljgs=$rs['dls4'];
        $v="<font>钻石代理</font>";
}elseif($vip==5){
    $dljg=$rs['dl5'];
    $dljgs=$rs['dls5'];
    $v="<font>至</font><font>尊</font><font>代</font><font>理</font>";
}
//$v="<font color='red'>VIP$vip</font>";
$config = $DB->get_row("SELECT * FROM auth_config");
$gonggao=$config['gg'];//公告获取
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

if($_POST['pass'] && $_POST['newpass']){
    $pass = daddslashes($_POST['pass']);
    $newpass = daddslashes($_POST['newpass']);
    if($DB->query("update `auth_daili` set `pass` ='$newpass' where `id`='$dlid' and `pass`='$pass' limit 1")){
        exit("<script language='javascript'>alert('密码修改成功！');history.go(-1);</script>");
    }else{
        exit("<script language='javascript'>alert('密码修改失败！');history.go(-1);</script>");
    }
}
//卡密
$rmb=$row['rmb'];
if($_GET['do']=="cz"){
$km = daddslashes($_POST['km']);
$kmrow = $DB->get_row("SELECT * FROM auth_kms WHERE km='{$km}' and kind=2 limit 1");    
if(!$kmrow){
    exit("<script>alert('卡密不存在');window.location.href='/daili';</script>");
    }elseif($kmrow['isuse']>0){
        exit("<script>alert('卡密已被使用');window.location.href='/daili';</script>");
    }else{
        $value = $kmrow['value'];
        $now_rmb = $rmb + $value;
        $DB->query("UPDATE auth_daili SET rmb='{$now_rmb}' WHERE id='{$dlid}'");
        $DB->query("UPDATE auth_kms SET isuse=1,usetime='".date("Y-m-d H:i:s")."',user='{$row['user']}' WHERE km='{$km}' and kind=2");
        //JXL_add for 2016-04-16 begin
        if($row['tj_user']){
            $rmb2=$value*$conf_rate;
            $sql2=$DB->query("update `auth_daili` set `tj_rmb`=`tj_rmb`+{$rmb2} where `user`='{$row['tj_user']}'");
        }
        //JXL_add for 2016-04-16 end
        wlog('代理充值','代理'.$row['user'].'使用卡密'.$km.'充值'.$value.'元['.$date.']');
        exit("<script>alert('成功充值".$value."元');window.location.href='/daili';</script>");
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12"><br>
                                          <h1 class="widget-heading h3 text-black"><strong>您好，代理<?php
$drs=$DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$user2=$drs['user'];
                             echo $user2;?>！<span class="label label-primary"><?php echo $v;?></span></strong></h1><br>
                                              
                                         
                                      </div>
									  
                                      
                                  </div>
                            </div>
					
					
					
					
					
					<div class="row">
                
                <div class="col-sm-12">
                    
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           修改密码
                        </div>
                        
                        <div class="panel-body">
                            
                            <div class="row">
                                <div class="col-sm-12">

                                  <form action="" method="POST" class="form-inline validate">
                                    <div class="form-group">
                                    <input type="text" class="form-control" name="pass" placeholder="当前密码" data-validate="required">
                                    <input type="text" class="form-control" name="newpass" placeholder="请输入新密码" data-validate="required">
                                    </div>
                                    <button type="submit" class="btn btn-secondary btn-info">确认</button>
                                  </form>
                                    
                                </div>
                            </div>
                            
                        </div>
                        
                    </div>
                </div>

            </div>

					
					
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	 <script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        
    </body>
</html>