<?php
/**
 * 我的推广
**/
$mod='blank';
include("../api.inc.php");
$title='我的推广';
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

$rs=$DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$user=$rs['user'];
$adtext=$rs['adtext'];
$adimg=$rs['adimg'];

?>
<!DOCTYPE html>
<html lang="en">

<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12"><br>
                                          <h1 class="widget-heading h3 text-black"><strong>您好，代理<?php
$drs=$DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$user2=$drs['user'];
                             echo $user2;?>！<span class="label label-primary"><?php echo $v;?></span></strong></h1><br>
                                              
                                         
                                      </div>
									  
                                      
                                  </div>
                            </div>
					
					
					
					
					<div class="row">
                
                <div class="col-sm-12">
                    
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            下面是您的推广信息
                        </div>
                        
                        <div class="panel-body">
                            
<?php
if($my=='black3'){

    $adtext_c=$_GET['adtext'];
    $adimg_c=$_GET['adimg'];
    //echo "<script language='javascript'>alert('推荐人：".$dlid."');</script>";
    if(/*$mima<>$rs['pass'] && */$adtext_c<>""){
    $sql=$DB->query("update `auth_daili` set `adimg`='$adimg_c', `adtext`='$adtext_c' where `id`='{$dlid}'");
    if($sql){echo '<div class="alert alert-success">
                                        <button type="button" class="close">
                                          <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                                <span class="sr-only">Close</span>
                                            </button>
                                            设置成功！
                                        </div>';
                //echo "<script language='javascript'>alert('".$qq_c."');</script>";
                echo "<style>#sale{display: none;}</style>";
                                      }
    else{echo '<div class="alert alert-danger">
                                            设置失败！
                                        </div>';}
    }else{
     echo "<div class='alert alert-warning'>
                                            <strong>为".$user."更改内容失败！</strong></div>";
                                        
    }

}
?>

                            <div  class="row">
                                

                                <div class="col-sm-12">
                                    <div class="blockquote blockquote-info text-center">
                                        <p>
                                            <strong>我的推广信息</strong>
                                        </p>
                                        <br>
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div id="qrcode"></div>
                                                <a target="_blank" href="/user/reg.php?dl=<?php echo $_SESSION['dlid'];?>" class="btn btn-info btn-icon btn-icon-standalone">
                                                    
                                                    <span>您的会员注册链接</span>
                                                </a>
                                            </div>
                                            <div class="col-sm-6">
                                                <div id="qrcode2"></div>
                                                <a target="_blank" href="ad.php?dl=<?php echo $_SESSION['dlid'];?>" class="btn btn-danger btn-icon btn-icon-standalone">
                                                    
                                                    <span>您的广告推广链接</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div> 
                                    <div class="blockquote blockquote-info">
                                        <p>
                                            <strong>我的推广站点</strong>
                                        </p>
                                        <br>
                                        <div class="row">
                                            <div class="col-sm-12">
                                              <?php
          
                                              $rs=$DB->query("SELECT * FROM `website` WHERE daili='$dlid' ");
                                              while($res = $DB->fetch($rs))
                                              {
                                              ?>
                                              <a class="btn btn-info btn-icon bg-lg" target="_blank" href="/web/index.php?name=<?=$res['name']?>" alt="点击浏览">
                                                    
                                                    <span>点击浏览</span>
                                                </a>
                                              <?php }
                                              ?>
                                            </div>
                                        </div>
                                    </div> 
                                </div>
                            </div>
                            
                        </div>
                        
                    </div>
                </div>

            </div>
					
					
					
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	 <script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>
		<script type="text/javascript" src="/assets/js/jquery.qrcode.min.js"></script>
<script>
jQuery('#qrcode').qrcode({
        render      : "canvas",//也可以替换为table
        width   : 172,
        height  : 172,
        text      : "http://<?php echo $_SERVER['HTTP_HOST'];?>/user/reg.php?dl=<?php echo $_SESSION['dlid'];?>"
});
jQuery('#qrcode2').qrcode({
        render      : "canvas",//也可以替换为table
        width   : 172,
        height  : 172,
        text      : "http://<?php echo $_SERVER['HTTP_HOST'];?>/daili/ad.php?dl=<?php echo $_SESSION['dlid'];?>"
});
</script>
        <!-- Load and execute javascript code used only in this page -->
        
    </body>
</html>