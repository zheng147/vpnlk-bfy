<?php
/**
 * 搜索授权
**/
$mod='blank';
include("../api.inc.php");
$title='搜索卡密';
$dlid=$_SESSION['dlid'];
$id = $_GET['id'];
if($id){
    $cz = $DB->get_row("SELECT * FROM `kmtype` WHERE `id` = '$id'");
    $rmb=$cz['km_rmb'];
}else{
    exit("<script language='javascript'>alert('这里是支付提交页面，你走错了！');window.location.href='/daili/login.php';</script>");
}
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">

<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12"><br>
                                          <h1 class="widget-heading h3 text-black"><strong>您好，代理<?php
$drs=$DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$user2=$drs['user'];
                             echo $user2;?>！<span class="label label-primary"><?php echo $v;?></span></strong></h1><br>
                                              
                                         
                                      </div>
									  
                                      
                                  </div>
                            </div>
					
					
					
					<div class="row">
                
                <div class="col-sm-12">
                    
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            在线充值
                        </div>
                        
                        <div class="panel-body">
                            
                            <div class="row">
                                <div class="col-sm-12">
                                    
                                    <form action="/pay/alipayapi.php" class="alipayform validate" method="post" target="_blank">
                                    <ul class="list-group list-group-minimal">
                                        <li class="list-group-item">
                                            <?php
                                            $d=time();
                                            ?>
                                            <span class="badge badge-roundless badge-warning"><?php echo "" . date("Ymdhis", $d);?></span>
                                            <input type="text" name="WIDout_trade_no" id="out_trade_no" value="<?php echo "" . date("Ymdhis", $d);?>" class="hide">
                                            订单号
                                        </li>
                                        <li class="list-group-item">
                                            <span class="badge badge-roundless badge-info">代理充值余额</span>
                                            <input type="text" name="WIDsubject" value="代理充值余额" class="hide">
                                            商品名称
                                        </li>
                                        <li class="list-group-item">
                                            <span class="badge badge-roundless badge-danger"><?php echo $rmb?></span>
                                            <input type="text" name="WIDtotal_fee" value="<?php echo $rmb?>" class="hide">
                                            充值面额
                                        </li>
                                        <input type="text" name="WIDbody" value="<?php echo $dlid?>" class="hide">
                                    </ul>
                                    <button type="submit" class="btn btn-success btn-icon btn-block">
                                        
                                        <span>确认支付</span>
                                    </button>
                                    </form>
                                    
                                </div>
                            </div>
                            
                        </div>
                        
                    </div>
                </div>

            </div>
					
					
					
					
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	 <script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        
    </body>
</html>