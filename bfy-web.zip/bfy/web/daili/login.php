<?php
/**
 * 登录
**/
$mod='blank';
include("../api.inc.php");
if(isset($_POST['user']) && isset($_POST['pass'])){
	$user=daddslashes($_POST['user']);
	$pass=daddslashes($_POST['pass']);
	$row = $DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
	$dlid=$row['id'];
	if($row['active']=="1" && $dlid<>""){
		
	}else{exit("<script language='javascript'>alert('用户不存在或未激活，如已经注册请联系管理员付费激活！');history.go(-1);</script>");}
	
	if($user==$row['user'] && $pass==$row['pass']) {
		$session=md5($user.$pass.$password_hash);
		$token=authcode("{$user}\t{$session}", 'ENCODE', SYS_KEY);
		//setcookie("ol_token", $token, time() + 604800);
		$row = $DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
		$dlid=$row['id'];
		$_SESSION['dlid']=$dlid;
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('登陆代理中心成功！');window.location.href='./';</script>");
	}elseif ($pass != $row['pass']) {
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('用户名或密码不正确！');history.go(-1);</script>");
	}
}elseif(isset($_GET['logout'])){
	setcookie("ol_token", "", time() - 604800);
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已成功注销本次登陆！');window.location.href='./login.php';</script>");
}elseif($islogin2==1){
	exit("<script language='javascript'>alert('您已登陆！');window.location.href='./';</script>");
}
$title='代理登录';
?>
<!doctype html>
<html lang="zh">
<head>
<?php
$rs=$DB->get_row("SELECT * FROM website");

$webtitle=$rs['title'];


?>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
<meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title><?php echo $webtitle ?> - <?php echo $title ?></title>
<link rel="stylesheet" type="text/css" href="../asset/login/styles.css">
</head>
<body  class="htmleaf-container">
<div class="htmleaf-container">
<script type="text/javascript">
                    jQuery(document).ready(function($)
                    {
                        // Reveal Login form
                        setTimeout(function(){ $(".fade-in-effect").addClass('in'); }, 1);
                        
                        
                        // Validation and Ajax action
                        $("form#login").validate({
                            rules: {
                                user: {
                                    required: true
                                },
                                
                                pass: {
                                    required: true
                                }
                            },
                            
                            messages: {
                                user: {
                                    required: '此为必填项！'
                                },
                                
                                pass: {
                                    required: '此为必填项！'
                                }
                            },
                            
                        });
                        
                        // Set Form focus
                        $("form#login .form-group:has(.form-control):first .form-control").focus();
                    });
                </script>

	<div class="wrapper">
		<div class="container">
		<form action="./login.php" method="post" role="form" id="login" class="login-form fade-in-effect">
				<b><h2><?php echo $webtitle ?> - <?php echo $title ?></h2><br></b>
			<form class="form">
				<input type="text" name="user" id="user" autocomplete="off" placeholder="帐号">
				<input type="password" name="pass" id="pass" autocomplete="off" placeholder="密码">
				 
				<button type="submit">登录</button>
				
				<div class="login-footer text-center">
                       <br> <a href="#">如忘记密码，请与管理员联系找回！</a>
				</div>
				 <div class="external-login">
                    <a href="reg.php" class="btn btn-purple text-center">
                       <br>  <i class="fa-edit"></i>
                        立即注册，成为代理！
                    </a>
                    
                    
                </div>
			</form>
			
		</div>
		
		<ul class="bg-bubbles">
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
		</ul>
	</div>
</div>
<script src="../asset/login/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
$('#login-button').click(function (event) {
	
	
		event.preventDefault();
		$('form').fadeOut(500);
		$('.wrapper').addClass('form-success');
		
	

});
</script>

</body>
</html>
