<?php
header("location: /web/"); 
?>