<?php
$mod='blank';
include("../api.inc.php");
$title='当前在线用户';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $rs = $DB->get_row("SELECT * FROM `auth_fwq` WHERE `id`='$id' limit 1");
    if(!$rs){
        echo "此服务器不存在";
    }else{
        $file = 'http://'.$rs['ipport'].'/res/tcp.txt';
        $file2 = 'http://'.$rs['ipport'].'/udp/udp.txt';
    }
}else{
    $file = '../res/tcp.txt';
    $file2 = '../udp/udp.txt';
}

?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                          <h1 class="widget-heading h3 text-black"><strong><?php echo $title ?></strong></h1>
                                              <h5>此处可以看到在线用户使用详细，刷新速度为你搭建时设置的时段</h5>
                                         
                                      </div>
									  
                                      <div class="col-sm-12">
                                          
                                              <ul class="breadcrumb breadcrumb-top">
                                                  <li><a href="index.php">返回首页</a></li>
                                                  <li><?php echo $title ?></li>
                                              </ul>
                                          
                                       </div>
                                  </div>
                            </div>
					
					
					
					
					
					
					<div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">平台共有 
                    <?php
                    //在线人数接口udp
                    $str=file_get_contents($file,false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                    $onlinenum_udp = (int)((substr_count($str,date('Y'))-1)/2);

                    //在线人数接口tcp
                    $str=file_get_contents($file2,false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                    $onlinenum = (int)((substr_count($str,date('Y'))-1)/2);
                    ?><?php echo round($onlinenum_udp+$onlinenum)?>
                                           人在线</h3>
                      
                      
                    </div>
                    <div class="panel-body">
                      <div class="row">
                          <div class="col-sm-6">
                            <div class="table-responsive">
                            
                                        <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                      <th>TCP协议-ID</th>
                                                      <th data-priority="1">用户名</th>
                                                      <th data-priority="3">上传</th>
                                                      <th data-priority="6">下载</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                  <?php
                                                  $str=file_get_contents($file);
                                                  $num=(substr_count($str,date('Y'))-1)/2;
                                                  $fp=fopen($file,"r");
                                                  fgets($fp);
                                                  fgets($fp);
                                                  fgets($fp);
                                                  for($i=0;$i<$num;$i++){
                                                  $j=$i+1;
                                                  echo "<tr>";
                                                      $line=fgets($fp);
                                                      $arr=explode(",",$line);
                                                      $recv=round($arr[2]/1024)/1000;
                                                      $sent=round($arr[3]/1024)/1000;
                                                      echo "<th>".$j."</th>";
                                                  echo "<td>".$arr[0]."</td>";
                                                  echo "<td>".$recv."MB</td>";
                                                  echo "<td>".$sent."MB</td>";
                                                  echo "</tr>";
                                                  }
                                                  ?>
                                            </tbody>
                                        </table>
                            
                            </div>
                          </div>
                          <div class="col-sm-6">
                            <div class="table-responsive">
                            
                                        <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                      <th>UDP协议-ID</th>
                                                      <th data-priority="1">用户名</th>
                                                      <th data-priority="3">上传</th>
                                                      <th data-priority="6">下载</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                  <?php
                                                  $str2=file_get_contents($file2);
                                                  $num=(substr_count($str2,date('Y'))-1)/2;
                                                  $fp=fopen($file2,"r");
                                                  fgets($fp);
                                                  fgets($fp);
                                                  fgets($fp);
                                                  for($i=0;$i<$num;$i++){
                                                  $j=$i+1;
                                                  echo "<tr>";
                                                      $line=fgets($fp);
                                                      $arr=explode(",",$line);
                                                      $recv=round($arr[2]/1024)/1000;
                                                      $sent=round($arr[3]/1024)/1000;
                                                      echo "<th>".$j."</th>";
                                                  echo "<td>".$arr[0]."</td>";
                                                  echo "<td>".$recv."MB</td>";
                                                  echo "<td>".$sent."MB</td>";
                                                  echo "</tr>";
                                                  }
                                                  ?>
                                            </tbody>
                                        </table>
                            
                            </div>
                          </div>

                      </div>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
					
					
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	<body>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>