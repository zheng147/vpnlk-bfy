<?php
$mod='blank';
include("../api.inc.php");
$title='代理列表';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                          <h1 class="widget-heading h3 text-black"><strong><?php echo $title ?></strong></h1>
                                              <h5>提示：默认代理ID必须是0，请勿修改删除！</h5>
                                         
                                      </div>
									  
                                      <div class="col-sm-12">
                                          
                                              <ul class="breadcrumb breadcrumb-top">
                                                  <li><a href="index.php">返回首页</a></li>
                                                  <li><?php echo $title ?></li>
                                              </ul>
                                          
                                       </div>
                                  </div>
                            </div>
					
					
					
					
					
					
					
					
<?php

$my=$_GET['my'];
if($my=='black1'){
$user=$_GET['user'];
echo '<div class="alert alert-black">
                    <button type="button" class="close" data-dismiss="alert">
                      <span aria-hidden="true">×</span>
                      <span class="sr-only">Close</span>
                    </button>';
$id=$_GET['id'];
$sql=$DB->query("update `auth_daili` set `active`='0' where `user`='{$user}'");
if($sql){echo '设置成功，状态为未激活！';}
else{echo '设置失败！';}
echo '</div>';
//exit;2016-07-29 19:53:20取消
}elseif($my=='black2'){
$user=$_GET['user'];
echo '<div class="panel panel-default panel-border panel-shadow">
                        <div class="panel-heading">
                           <h3 class="panel-title"> 代理充值</h3>
                <div class="panel-options">
                                <a href="#">
                                  <i class="linecons-cog"></i>
                                </a>
                                
                                <a href="#" data-toggle="panel">
                                  <span class="collapse-icon">–</span>
                                  <span class="expand-icon">+</span>
                                </a>
                                
                                <a href="#" data-toggle="reload">
                                  <i class="fa-rotate-right"></i>
                                </a>
                                
                                <a href="#" data-toggle="remove">
                                  ×
                                </a>
                              </div>
                        </div>
                        <div class="panel-body">
<form action="./daili.php?" method="get" class="form-inline validate" role="form">
            <div class="form-group">
            <input type="text" name="user" value='.$user.' hidden />
            <input type="text" name="my" value="black2" hidden/>
              <input type="text" name="s" size="25" value="" class="form-control"  placeholder="为'.$user.'充值多少金额？" data-validate="required,number"/>
            </div>
            <input type="submit" value="充值" class="btn btn-secondary btn-single"/>
          </form>
</div>
                    </div>';
if($_GET['s'] && $_GET['user']){
  $s=$_GET['s'];
    if($s>999999){
    exit("<script language='javascript'>alert('数据非法！');history.go(-1);</script>");
  }
  //$user=$_GET['user'];
  echo '<div class="alert alert-success">
                                        <button type="button" class="close" data-dismiss="alert">
                                            <span aria-hidden="true">×</span>
                                            <span class="sr-only">Close</span>
                                        </button>为 ';
  echo $user;
  $rs=$DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
  $rmb=$rs['rmb']+$s;
  $sql=$DB->query("update `auth_daili` set `rmb`='$rmb' where `user`='{$user}'");
  //JXL_add for 2016-04-16 begin
  if($rs['tj_user']){
    $rmb2=$s*$conf_rate;
    $sql2=$DB->query("update `auth_daili` set `tj_rmb`=`tj_rmb`+{$rmb2} where `user`='{$rs['tj_user']}'");
  }
  //JXL_add for 2016-04-16 end
  if($sql){
    echo ' 充值成功，'.$s.'元！</div>';
    wlog('代理充值','管理员为代理'.$user.'充值'.$s.'元['.$date.']');
  }else{
    echo '充值失败！';
  }
echo '';
}else{echo '';}
//exit;2016-07-29 19:53:20取消
}elseif($my=='black3'){
$user=$_GET['user'];
$rs=$DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
$name=$rs['name'];
$qq=$rs['qq'];
$tel=$rs['tel'];
$buy=$rs['buy'];
$buy2=$rs['buy2'];
echo '<div id="daili_info" class="panel panel-default panel-border panel-shadow"><!-- Add class "collapsed" to minimize the panel -->
                        <div class="panel-heading">
                            <h3 class="panel-title">修改信息</h3>
                            
                            <div class="panel-options">
                                <a href="#">
                                    <i class="linecons-cog"></i>
                                </a>
                                
                                <a href="#" data-toggle="panel">
                                    <span class="collapse-icon">–</span>
                                    <span class="expand-icon">+</span>
                                </a>
                                
                                <a href="#" data-toggle="reload">
                                    <i class="fa-rotate-right"></i>
                                </a>
                                
                                <a href="#" data-toggle="remove">
                                    ×
                                </a>
                            </div>
                        </div>
                        
                        <div class="panel-body">
<form action="./daili.php?" method="get" class="form-horizontal validate" role="form">
            <input type="text" name="user" value='.$user.' hidden />
            <input type="text" name="my" value="black3" hidden/>
<div class="form-group">
  <label class="col-sm-2 control-label" for="field-1">姓名</label>
  <div class="col-sm-10">
    <input type="text" class="form-control"id="field-1" value="'.$name.'" name="name" data-validate="required"/>
  </div>
</div>
<div class="form-group">
  <label class="col-sm-2 control-label" for="field-2">密码</label>
  <div class="col-sm-10">
    <input type="text" class="form-control"id="field-2" value="'.$rs['pass'].'" name="mima" data-validate="required"/>
  </div>
</div>
<div class="form-group">
  <label class="col-sm-2 control-label" for="field-3">QQ</label>
  <div class="col-sm-10">
    <input type="text" class="form-control"id="field-3" value="'.$qq.'" name="qq" data-validate="required"/>
  </div>
</div>
<div class="form-group">
  <label class="col-sm-2 control-label" for="field-4">电话</label>
  <div class="col-sm-10">
    <input type="text" class="form-control"id="field-4" value="'.$tel.'" name="tel" data-validate="required"/>
  </div>
</div>
<div class="form-group">
  <label class="col-sm-2 control-label" for="field-4">购买链接</label>
  <div class="col-sm-10">
    <input type="text" class="form-control"id="field-4" value="'.$buy.'" name="buy" data-validate="url"/>
  </div>
</div>
<div class="form-group">
  <label class="col-sm-2 control-label" for="field-4">支付代码</label>
  <div class="col-sm-10">
    <textarea class="form-control" cols="5" id="field-5" name="buy2">'.$buy2.'</textarea>
  </div>
</div>
<div class="form-group">
  <label class="col-sm-2 control-label"></label>
  <div class="col-sm-10">
    <input type="submit" value="修改" class="btn btn-purple btn-single"/>
  </div>
</div>
          </form>
                        </div>
                    </div>';
$mima=$_GET['mima'];
$name_c=$_GET['name'];
$qq_c=$_GET['qq'];
$tel_c=$_GET['tel'];
$buy_c=$_GET['buy'];
$buy2_c=$_GET['buy2'];
if(/*$mima<>$rs['pass'] && */$mima<>""){
$sql=$DB->query("update `auth_daili` set `name`='$name_c', `pass`='$mima', `qq`='$qq_c', `tel`='$tel_c', `buy`='$buy_c', `buy2`='$buy2_c' where `user`='{$user}'");
if($sql){echo '<div class="alert alert-success">
                                        <button type="button" class="close" data-dismiss="alert">
                                            <span aria-hidden="true">×</span>
                                            <span class="sr-only">Close</span>
                                        </button>
                                        设置成功！
                                    </div>';
            //echo "<script language='javascript'>alert('".$qq_c."');</script>";
            echo "<style>#daili_info{display: none;}</style>";
                                  }
else{echo '<div class="alert alert-danger">
                                        设置失败！
                                    </div>';}
}else{
 echo "<div class='alert alert-warning'>
                                        为<strong>".$user."</strong> 更改信息，密码不能为空！</div>";
                                    
}
echo '';
//exit;2016-07-29 19:53:20取消
}elseif($my=='black0'){
$user=$_GET['user'];
echo '<div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert">
                      <span aria-hidden="true">×</span>
                      <span class="sr-only">Close</span>
                    </button>';
$id=$_GET['id'];
$sql=$DB->query("update `auth_daili` set `active`='1' where `user`='{$user}'");
if($sql){echo '设置成功，状态为已激活！';}
else{echo '设置失败！';}
echo '</div>';
//exit;2016-07-29 19:53:20取消
}elseif($my=="vip"){
  $user=$_GET['user'];
  $rs=$DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
  $vip=$rs['vip'];
echo '<div class="panel panel-default panel-border panel-shadow"><!-- Add class "collapsed" to minimize the panel -->
                        <div class="panel-heading">
                            <h3 class="panel-title">更改代理级别</h3>
                            
                            <div class="panel-options">
                                <a href="#">
                                    <i class="linecons-cog"></i>
                                </a>
                                
                                <a href="#" data-toggle="panel">
                                    <span class="collapse-icon">–</span>
                                    <span class="expand-icon">+</span>
                                </a>
                                
                                <a href="#" data-toggle="reload">
                                    <i class="fa-rotate-right"></i>
                                </a>
                                
                                <a href="#" data-toggle="remove">
                                    ×
                                </a>
                            </div>
                        </div>
                        
                        <div class="panel-body">
<div class="alert alert-default">
                    <button type="button" class="close" data-dismiss="alert">
                      <span aria-hidden="true">×</span>
                      <span class="sr-only">Close</span>
                    </button>
                    <strong> 为'.$user.'更新代理级别！</strong>
                  </div>
<form action="./daili.php?" method="get" class="form-inline" role="form">
            <div class="form-group">
            <input type="text" name="user" value='.$user.' hidden />
            <input type="text" name="my" value="vip" hidden/>
             <select name="vip" class="form-control">
                <option value="0">普通代理</option>
                <option value="1">铜牌代理</option>
                <option value="2">银牌代理</option>
                <option value="3">金牌代理</option>
                <option value="4">钻石代理</option>
                <option value="5">至尊代理</option>
              </select>
            </div>
            <input type="submit" value="升级" class="btn btn-turquoise btn-single"/>
          </form>
                        </div>
                    </div>';
if(isset($_GET['vip']) && $_GET['user']){
  $vip=$_GET['vip'];
  //$user=$_GET['user'];
  if($vip>5){
    exit("<script language='javascript'>alert('数据非法！');history.go(-1);</script>");
  }
  echo '<div class="alert alert-success">
                                        <button type="button" class="close" data-dismiss="alert">
                                            <span aria-hidden="true">×</span>
                                            <span class="sr-only">Close</span>
                                        </button>
                                    ';
  echo $user;
  $rs=$DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
  $sql=$DB->query("update `auth_daili` set `vip`='$vip' where `user`='{$user}'");
  if($sql){echo '升级成功，当前为VIP'.$vip.'';}
else{echo '升级失败！';}
echo '</div>';
}else{echo '';}
//exit;2016-07-29 19:53:20取消
}elseif($my=="del"){
  $user=$_GET['user'];
  echo '<div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert">
                      <span aria-hidden="true">×</span>
                      <span class="sr-only">Close</span>
                    </button>';
  //$sql=$DB->query("DELETE FROM auth_kms WHERE id='$id'");删除单行
  $sql=$DB->query("DELETE FROM auth_daili WHERE user='$user'");
if($sql){echo '删除代理'.$user.'成功！';}
else{echo '删除失败！';}
echo '</div>';
//exit;2016-07-29 19:53:20取消
}
//JXL_add for 2016-04-16 begin
elseif($my=="empty"){
  $user=$_GET['user'];
$sql=$DB->query("update `auth_daili` set `tj_rmb`='0.00' where `user`='{$user}'");
if($sql){echo '<div class="alert alert-success">
                                        <button type="button" class="close" data-dismiss="alert">
                                            <span aria-hidden="true">×</span>
                                            <span class="sr-only">Close</span>
                                        </button>
                                    清空'.$user.'推荐余额成功！</div>';}
else{echo '<div class="alert alert-danger">清空失败！</div>';}
echo '';

//foot();2016-07-29 19:53:20取消
//exit;2016-07-29 19:53:20取消
}
elseif($my=='km'){//清空卡密结果
echo '<div class="alert';
$daili=$_GET['daili'];
if($DB->query("DELETE FROM auth_kms WHERE daili='$daili' AND kind='1' AND  `user` IS NULL")==true){
echo ' alert-success">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>清空成功！';
}else{
echo' alert-danger">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>清空失败！';
}
echo '</div>';
}
//JXL_add for 2016-04-16 end

 ?>

            <?php
            if(isset($_GET['sdl'])) {
              $sdl=$_GET['sdl'];
              $dl="1";
              if($_GET['type']==1) {
                $sql=" `user`='{$_GET['sdl']}'";
                $numrows=$DB->count("SELECT count(*) from `auth_daili` WHERE{$sql}");
                $con='包含 '.$_GET['sdl'].' 的共有 '.$numrows.' 个信息';
              }elseif($_GET['type']==2) {
                $sql=" `vip`='{$_GET['kw']}'";
                $numrows=$DB->count("SELECT count(*) from `auth_daili` WHERE{$sql}");
                $con='包含 '.$_GET['kw'].' 的共有 '.$numrows.' 个信息';
              }
            }else{
              $numrows=$DB->count("SELECT count(*) from `auth_daili` WHERE 1");
              $sql=" 1";
              $con='平台共有 '.$numrows.' 个代理信息';
            }
            ?>

            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title"><?php echo $con; ?></h3>
                      
                      
                    </div>
                    <div class="panel-body">

                      <form action="./daili.php" method="get" role="form" class="form-inline validate">
                      <a href="dlconfig.php" class="btn btn-info">高级设置</a>
                        
                        <div class="form-group pull-right">

                        <div class="form-group">

                          <select class="form-control">
                            <option value="1">代理用户名</option>
                            <option value="2">代理级别</option>
                          </select>
                            
                        </div>

                        <div class="form-group">
                          <input type="text" class="form-control" size="25" placeholder="内容" name="sdl" data-validate="required">
                        </div>

                        <div class="form-group">
                          <button type="submit" class="btn btn-success btn-single">查询</button>
                        </div>
                        
                        </div>
                        
                      </form>

                      <div class="table-responsive">
                      
                                  <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                      <thead>
                                      <tr>
                                          <th>ID</th>
                                          <th data-priority="1">用户名</th>
                                          <th data-priority="6">密码</th>
                                          <th data-priority="6">状态</th>
                                          <th data-priority="6">等级</th>
                                          <th data-priority="6">账户余额</th>
                                          <th data-priority="6">支付宝收入</th>
                                          <th data-priority="6">推荐人</th>
                                          <th data-priority="6">已获推荐余额</th>
                                          <th data-priority="6">姓名</th>
                                          <th data-priority="6">QQ</th>
                                          <th data-priority="6">电话</th>
                                          <th data-priority="6">操作</th>
                                      </tr>
                                      </thead>
                                      <tbody>
            <?php
            $pagesize=30;
            $pages=intval($numrows/$pagesize);
            if ($numrows%$pagesize)
            {
             $pages++;
             }
            if (isset($_GET['page'])){
            $page=intval($_GET['page']);
            }
            else{
            $page=1;
            }
            $offset=$pagesize*($page - 1);
            if($dl=="1"){
            $rs=$DB->query("SELECT * FROM auth_daili  where user='$sdl' limit $offset,$pagesize");
            }else{
            $rs=$DB->query("SELECT * FROM auth_daili   limit $offset,$pagesize");
            }

            $dengji = array('普通代理','铜牌代理','银牌代理','金牌代理','钻石代理');

            while($res = $DB->fetch($rs))
            {
            if($res['active']==0){
              $isactive='<span class="badge badge-primary">未激活</span>';
            }elseif($res['active']==1){
              $isactive='<span class="badge badge-secondary">已激活</span>';
            }
            if($res['id']==0) {
                $del='<button class="btn btn-xs btn-gray disabled">此代理不可删除</button>';
            } else {
                $del='<a href="./daili.php?my=del&user='.$res['user'].'" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要进行操作吗？\');">删除</a>';
            } 
            echo '<tr><th><span class="co-name">'.$res['id'].'</span></th><td>'.$res['user'].'</td><td>'.$res['pass'].'</td><td>'.$isactive.'</td><td>'.$dengji[$res['vip']].'</td><td>'.$res['rmb'].'</td><td><p class="text-danger">'.$res['income'].'</p></td><!-- JXL_add for 2016-04-16 begin --><td>'.$res['tj_user'].'</td><td>'.$res['tj_rmb'].'</td><td>'.$res['name'].'</td><td>'.$res['qq'].'</td><td>'.$res['tel'].'</td><!-- JXL_add for 2016-04-16 end --><td>'.($res['active']==1?'<a href="./daili.php?my=black1&user='.$res['user'].'" class="btn btn-xs btn-primary" onclick="return confirm(\'你确实要更改状态吗？\');">设为未激活</a>':'<a href="./daili.php?my=black0&user='.$res['user'].'" class="btn btn-xs btn-success" onclick="return confirm(\'你确实要将此代理激活吗？\');">设置为激活</a>').'<a href="./daili.php?my=black2&user='.$res['user'].'" class="btn btn-xs btn-secondary">为其充值</a><a href="./daili.php?my=black3&user='.$res['user'].'" class="btn btn-xs btn-purple">修改信息</a><a href="./daili.php?my=vip&user='.$res['user'].'" class="btn btn-xs btn-turquoise">设置等级</a><!-- JXL_add for 2016-04-16 begin --><a href="./daili.php?my=empty&user='.$res['user'].'" class="btn btn-xs btn-orange" onclick="return confirm(\'你确实要进行操作吗？\');">清空推荐余额</a><a href="./daili.php?my=km&daili='.$res['id'].'" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要清空代理：'.$res['user'].'名下未使用卡密吗？\');">清空卡密</a><!-- JXL_add for 2016-04-16 end -->'.$del.'</td></tr>';
            }
            ?>
                                      </tbody>
                                  </table>
                      
                      </div>
                      
                      <?php
                      echo'<ul class="pagination pagination-sm">';
                      $first=1;
                      $prev=$page-1;
                      $next=$page+1;
                      $last=$pages;
                      if ($page>1)
                      {
                      echo '<li><a href="daili.php?page='.$first.$link.'">首页</a></li>';
                      echo '<li><a href="daili.php?page='.$prev.$link.'">&laquo;</a></li>';
                      } else {
                      echo '<li class="disabled"><a>首页</a></li>';
                      echo '<li class="disabled"><a>&laquo;</a></li>';
                      }
                      for ($i=1;$i<$page;$i++)
                      echo '<li><a href="daili.php?page='.$i.$link.'">'.$i .'</a></li>';
                      echo '<li class="disabled"><a>'.$page.'</a></li>';
                      for ($i=$page+1;$i<=$pages;$i++)
                      echo '<li><a href="daili.php?page='.$i.$link.'">'.$i .'</a></li>';
                      echo '';
                      if ($page<$pages)
                      {
                      echo '<li><a href="daili.php?page='.$next.$link.'">&raquo;</a></li>';
                      echo '<li><a href="daili.php?page='.$last.$link.'">尾页</a></li>';
                      } else {
                      echo '<li class="disabled"><a>&raquo;</a></li>';
                      echo '<li class="disabled"><a>尾页</a></li>';
                      }
                      echo'</ul>';
                      #分页

                      ?>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
					
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	<body>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>