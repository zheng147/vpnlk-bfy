<?php
/**
 * 添加线路
**/
$mod='blank';
include("../api.inc.php");
$title='激活线路';
if(is_file("../../../install.lock")){
  header("location:openlist.php");
}
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body">

    <?php include 'set.php';?>
    
    <div class="page-container">

        <?php include 'nav.php';?>
        
        <div class="main-content">
                    
            <?php include 'info.php';?>
            
          <div class="page-title">
          <div class="title-env">
            <h1 class="title"><?php echo $title ?></h1>
            <p class="description">此处为安装完成搭建，激活自带云端线路</p>
          </div>
            <div class="breadcrumb-env">
            
               <ol class="breadcrumb bc-1">
                 <li>
                  <a href="index.php"><i class="fa-home"></i>首页</a>
                </li>
                <li class="active">
                      <strong><?php echo $title ?></strong>
                  </li>
              </ol>
                  
             </div>
           </div>

            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">默认信息</h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">
<?php
$bind_domain = explode(":",$_SERVER["HTTP_HOST"]);
if($_POST['ip']){
echo '<div class="alert '; 
$ip = $_REQUEST['ip']; 
$vpn = $_REQUEST['vpn']; 
$ca = $_REQUEST['ca']; 
$key = $_REQUEST['key'];   

  $DB->query("UPDATE open SET mo = REPLACE( mo,   '【ip】',  '$ip');");
  $DB->query("UPDATE open SET mo = REPLACE( mo,   '【vpn】',  '$vpn');");
  $DB->query("UPDATE open SET mo = REPLACE( mo,   '【证书】',  '$ca');");
  $DB->query("UPDATE open SET mo = REPLACE( mo,   '【key】',  '$key');");

  file_put_contents("../../../install.lock","删除此文件可以重新激活线路，且确保清空open表，导入默认线路包");

if(is_file("../../../install.lock"))
echo 'alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>成功激活默认线路，现在去配置流量卫士即可同步线路【如需重新激活，清空open表，导入默认线路包后，使用Xftp链接服务器打开/home，删除install.lock】</div>
                <a href="llws.php" class="btn btn-info btn-icon btn-icon-standalone">
                  <i class="fa-list-ol"></i>
                  <span>配置流量卫士</span>
                </a>
                <style>#newopen{display: none;}</style>'; 
else
                echo 'alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  添加失败</div>
                <a href="javascript:history.go(-1)" class="btn btn-info btn-icon btn-icon-standalone">
                  <i class="fa-list-ol"></i>
                  <span>返回上一步</span>
                </a>
                <style>#newopen{display: none;}</style>'; 
//exit;  
}
?>
<!--textarea class="form-control" cols="5" id="field-5" rows="6" data-validate="required"><?php echo $key ?></textarea-->

                    <form id="newopen" action="./newopen.php" method="post" class="form-horizontal validate" role="form">
                      <div class="form-group">
                        <label class="col-sm-2 control-label">您的IP：</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" id="field-1" value="<?php echo $bind_domain[0] ?>" name="ip" data-validate="required">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="col-sm-2 control-label">VPN端口</label>
                        <div class="col-sm-2">
                                <label class="radio-inline">
                                  <input type="radio" name="vpn" checked="" value="440">
                                  440
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="vpn" value="443">
                                  443
                                </label>
                        </div>
                        <div class="col-sm-5">
                          <p class="text-info" style="line-height: 31px;">* 必须与搭建时候选择一致</p>
                        </div>
                      </div>  

                      <div class="form-group">
                        <label class="col-sm-2 control-label">您的证书：</label>
                        <div class="col-sm-9">
                           <textarea class="form-control" cols="5" id="field-5" name="ca" rows="6" data-validate="required"><?php
                                $myfile = fopen("../ca.crt", "r") or die("没有找到ca.crt");
                                echo fread($myfile,filesize("../ca.crt"));
                                fclose($myfile);
                                ?></textarea>
                        </div>
                      </div>  

                      <div class="form-group">
                        <label class="col-sm-2 control-label">您的Key：</label>
                        <div class="col-sm-9">
                           <textarea class="form-control" cols="5" id="field-5" name="key" rows="6" data-validate="required"><?php
                                $myfile = fopen("../ta.key", "r") or die("没有找到ta.key");
                                echo fread($myfile,filesize("../ta.key"));
                                fclose($myfile);
                                ?></textarea>
                        </div>
                      </div>  

                      <div class="form-group">
                        <label class="col-sm-2 control-label"></label>
                        <div class="col-sm-9">
                          <button type="submit" type="button" class="btn btn-info btn-block">立即激活默认线路</button>
                        </div>
                      </div>
                    </form>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
        </div>
        
        </div>
        
    </div>

    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>


    <!-- Imported scripts on this page -->
    <script src="../assets/js/xenon-widgets.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/globalize.min.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/dx.chartjs.js"></script>
    <script src="../assets/js/toastr/toastr.min.js"></script>

    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html>