<?php
/**
 * 分站设置
**/
$mod='blank';
include("../api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

$title='分站设置';
$id = daddslashes($_GET['id']);
$rs=$DB->get_row("SELECT * FROM website where id='$id'");
$logo=$rs['logo'];
$webtitle=$rs['title'];
$qq=$rs['qq'];
$tel=$rs['tel'];
$app1=$rs['app1'];
$app2=$rs['app2'];
//$ipinfo=$rs['ipinfo'];
$appleid1=$rs['appleid1'];
$appleps1=$rs['appleps1'];
$appleid2=$rs['appleid2'];
$appleps2=$rs['appleps2'];
$appleid3=$rs['appleid3'];
$appleps3=$rs['appleps3'];
$and_img1=$rs['and_img1'];
$and_img2=$rs['and_img2'];
$and_img3=$rs['and_img3'];
$and_img4=$rs['and_img4'];
$jia1=$rs['jia1'];
$jia2=$rs['jia2'];
$jia3=$rs['jia3'];
$jia4=$rs['jia4'];
$daili=$rs['daili'];
$name=$rs['name'];
if($name=='dmg'){
  echo "<style>#field-name, #field-d{display: none;}</style>";
};
$dllist=$DB->query("SELECT * FROM auth_daili");
?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                          <h1 class="widget-heading h3 text-black"><strong><?php echo $title ?></strong></h1>
                                              <h5>这里可以管理分站的基本信息。</h5>
                                         
                                      </div>
									  
                                      <div class="col-sm-12">
                                          
                                              <ul class="breadcrumb breadcrumb-top">
                                                  <li><a href="index.php">返回首页</a></li>
                                                  <li><?php echo $title ?></li>
                                              </ul>
                                          
                                       </div>
                                  </div>
                            </div>
					<!--end--><!--end--><!--end--><!--end--><!--end--><!--end--><!--end--><!--end-->
					
					       
					
					
					<div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">请输入内容进行更新</h3>
                      
                      
                    </div>
                    <div class="panel-body">
<div id="tip" class="alert alert-default">
<button type="button" class="close" data-dismiss="alert">
  <span aria-hidden="true">×</span>
  <span class="sr-only">Close</span>
</button>
图片和软件都是通过第三方平台上传后，复制文件地址粘贴至文本框即可
<br><br>
<span class="input-group-btn" style="display: inline-table;">
  <button type="button" class="btn btn-purple dropdown-toggle" data-toggle="dropdown">
    图片上传平台 <span class="caret"></span>
  </button>
  <ul class="dropdown-menu dropdown-purple no-spacing">
    <li><a target="_blank" href="https://www.niupic.com/">牛图网</a></li>
    <li><a target="_blank" href="http://img.hoop8.com/index.php">Hoop8</a></li>
    <li><a target="_blank" href="http://chuantu.biz/">Chuantu.biz</a></li>
  </ul>
</span>
<span class="input-group-btn" style="display: inline-table;">
  <button type="button" class="btn btn-red dropdown-toggle" data-toggle="dropdown">
    APP上传平台 <span class="caret"></span>
  </button>
  <ul class="dropdown-menu dropdown-red no-spacing">
    <li><a target="_blank" href="http://fir.im/">fir.im</a></li>
    <li><a target="_blank" href="http://pre.im/">pre.im</a></li>
    <li><a target="_blank" href="https://www.pgyer.com/">蒲公英</a></li>
  </ul>
</span>
</div>
<?php

$my=$_POST['my'];
if($my=='config'){
echo '<div class="alert';
$logo_c=$_POST['logo'];
$webtitle_c=$_POST['webtitle'];
$qq_c=$_POST['qq'];
$tel_c=$_POST['tel'];
$app1_c=$_POST['app1'];
$app2_c=$_POST['app2'];
//$ipinfo_c=$_POST['ipinfo'];
$appleid1_c=$_POST['appleid1'];
$appleps1_c=$_POST['appleps1'];
$appleid2_c=$_POST['appleid2'];
$appleps2_c=$_POST['appleps2'];
$appleid3_c=$_POST['appleid3'];
$appleps3_c=$_POST['appleps3'];
//$appleid_c="账号：".$_POST['appleid_u1']."<br>密码：".$_POST['appleid_p1']."<br><br>账号：".$_POST['appleid_u2']."<br>密码：".$_POST['appleid_p2']."<br><br>账号：".$_POST['appleid_u3']."<br>密码：".$_POST['appleid_p3'];
$and_img1_c=$_POST['and_img1'];
$and_img2_c=$_POST['and_img2'];
$and_img3_c=$_POST['and_img3'];
$and_img4_c=$_POST['and_img4'];
$jia1_c=$_POST['jia1'];
$jia2_c=$_POST['jia2'];
$jia3_c=$_POST['jia3'];
$jia4_c=$_POST['jia4'];
$daili_c=$_POST['daili'];
$name_c=$_POST['name'];


$sql=$DB->query("UPDATE `website` SET `logo` = '$logo_c',`title` = '$webtitle_c',`qq`='$qq_c',`tel`='$tel_c',`app1`='$app1_c',`app2`='$app2_c',`appleid1`='$appleid1_c',`appleps1`='$appleps1_c',`appleid2`='$appleid2_c',`appleps2`='$appleps2_c',`appleid3`='$appleid3_c',`appleps3`='$appleps3_c',`and_img1`='$and_img1_c',`and_img2`='$and_img2_c',`and_img3`='$and_img3_c',`and_img4`='$and_img4_c',`jia1`='$jia1_c',`jia2`='$jia2_c',`jia3`='$jia3_c',`jia4`='$jia4_c',`daili`='$daili_c',`name`='$name_c' WHERE `website`.`id` = ".$id);
  
if($sql){echo ' alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>保存成功！';}
else{echo ' alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>保存失败！';}
echo '</div>';
//echo $appleid_c2;
//exit;
echo "<style>#webset, #tip{display: none;}</style>";
}

 ?>

              <form id="webset" action="./webset.php?id=<?php echo $id;?>" method="post" role="form" class="form-horizontal validate">
                
                <div class="form-group">
                  <input type="hidden" name="my" value="config"/>
                  <label class="col-sm-2 control-label">网站LOGO</label>
                  <div class="col-sm-10">
                    <div class="input-group">
                      <span class="input-group-addon">114px*65px</span>
                      <input type="text" class="form-control" value="<?php echo $logo;?>" name="logo" data-validate="required,url">
                      <span class="input-group-addon"><a target="_blank" href="<?php echo $logo;?>"><i class="linecons-search"></i></a></span>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label">网站名称</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="field-1" value="<?php echo $webtitle;?>" name="webtitle" data-validate="required">
                  </div>
                </div>

                <div class="form-group" id="field-name">
                  <label class="col-sm-2 control-label">子站代号</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="field-1" value="<?php echo $name;?>" name="name" data-validate="required">
                  </div>
                </div>

                <div class="form-group" id="field-d">
                  <label class="col-sm-2 control-label">所属代理</label>
                  <div class="col-sm-10">
                      <select class="form-control" name="daili">
                      <?php while($d = $DB->fetch($dllist)): ?>
                        <option value="<?php echo $d['id']; ?>"  <?php if($d['id'] == $rs['daili'])echo "selected=\"selected\"";?>>用户名：<?php echo $d['user']; ?>；姓名：<?php echo $d['name']; ?></option>
                      <?php endwhile; ?>
                      </select>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label">QQ号码</label>
                  <div class="col-sm-10">
                    <div class="input-group">
                      <input type="text" class="form-control no-right-border form-focus-info" id="field-1" value="<?php echo $qq;?>" name="qq" data-validate="required,number">
                        <span class="input-group-btn">
                          <a target="_blank" href="http://shang.qq.com/v3/index.html" class="btn btn-info" type="button">激活QQ</a>
                        </span>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label">电话号码</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="field-1" value="<?php echo $tel;?>" name="tel" data-validate="required">
                  </div>
                </div>

                <div class="form-group">
                  <input type="hidden" name="my" value="config"/>
                  <label class="col-sm-2 control-label">首页公示价格</label>
                  <div class="col-sm-10">
                    <div class="row">
                      <div class="col-sm-3">
                        <div class="input-group">
                          <span class="input-group-addon">流量体验</span>
                          <input type="text" class="form-control" size="5" value="<?php echo $jia1;?>" name="jia1" data-validate="required,number">
                          <span class="input-group-addon">元</span>
                        </div>
                      </div>
                      <div class="col-sm-3">
                        <div class="input-group">
                          <span class="input-group-addon">按量计费</span>
                          <input type="text" class="form-control" size="5" value="<?php echo $jia2;?>" name="jia2" data-validate="required,number">
                          <span class="input-group-addon">元起</span>
                        </div>
                      </div>
                      <div class="col-sm-3">
                        <div class="input-group">
                          <span class="input-group-addon">包月计费</span>
                          <input type="text" class="form-control" size="5" value="<?php echo $jia3;?>" name="jia3" data-validate="required,number">
                          <span class="input-group-addon">元</span>
                        </div>
                      </div>
                      <div class="col-sm-3">
                        <div class="input-group">
                          <span class="input-group-addon">代理加盟</span>
                          <input type="text" class="form-control" size="5" value="<?php echo $jia4;?>" name="jia4" data-validate="required,number">
                          <span class="input-group-addon">元起</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="form-group-separator"></div>

                <div class="form-group">
                  <label class="col-sm-2 control-label">安卓APP下载链接</label>
                  <div class="col-sm-10">
                    <div class="row">
                      <div class="col-sm-6">
                        <div class="input-group">
                          <input type="text" class="form-control" size="5" value="<?php echo $app1;?>" name="app1" data-validate="required">
                          <span class="input-group-addon">版本1</span>
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="input-group">
                          <input type="text" class="form-control" size="5" value="<?php echo $app2;?>" name="app2" data-validate="required">
                          <span class="input-group-addon">版本2</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label">苹果ID</label>
                  <div class="col-sm-10">
                    <div class="row">
                      <div class="col-sm-4">
                        <input type="text" class="form-control" size="25" value="<?php echo $appleid1;?>" name="appleid1" data-validate="required,email">
                        <input type="text" class="form-control" size="25" value="<?php echo $appleps1;?>" name="appleps1" data-validate="required">
                      </div>
                      <div class="col-sm-4">
                        <input type="text" class="form-control" size="25" value="<?php echo $appleid2;?>" name="appleid2" data-validate="required,email">
                        <input type="text" class="form-control" size="25" value="<?php echo $appleps2;?>" name="appleps2" data-validate="required">
                      </div>
                      <div class="col-sm-4">
                        <input type="text" class="form-control" size="25" value="<?php echo $appleid3;?>" name="appleid3" data-validate="required,email">
                        <input type="text" class="form-control" size="25" value="<?php echo $appleps3;?>" name="appleps3" data-validate="required">
                      </div>
                    </div>
                    <!--textarea class="form-control" cols="5" id="field-5" placeholder="请输入" name="appleid"><?php echo $appleid;?></textarea-->
                  </div>
                </div>

                <div class="form-group-separator"></div>

                <div class="form-group">
                  <label class="col-sm-2 control-label">安卓截图1</label>
                  <div class="col-sm-10">
                    <div class="input-group">
                      <span class="input-group-addon">宽高不限制</span>
                      <input type="text" class="form-control" value="<?php echo $and_img1;?>" name="and_img1" data-validate="required,url">
                      <span class="input-group-addon"><a target="_blank" href="<?php echo $and_img1;?>"><i class="linecons-search"></i></a></span>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">安卓截图2</label>
                  <div class="col-sm-10">
                    <div class="input-group">
                      <span class="input-group-addon">宽高不限制</span>
                      <input type="text" class="form-control" value="<?php echo $and_img2;?>" name="and_img2" data-validate="required,url">
                      <span class="input-group-addon"><a target="_blank" href="<?php echo $and_img2;?>"><i class="linecons-search"></i></a></span>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">安卓截图3</label>
                  <div class="col-sm-10">
                    <div class="input-group">
                      <span class="input-group-addon">宽高不限制</span>
                      <input type="text" class="form-control" value="<?php echo $and_img3;?>" name="and_img3" data-validate="required,url">
                      <span class="input-group-addon"><a target="_blank" href="<?php echo $and_img3;?>"><i class="linecons-search"></i></a></span>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">安卓截图4</label>
                  <div class="col-sm-10">
                    <div class="input-group">
                      <span class="input-group-addon">宽高不限制</span>
                      <input type="text" class="form-control" value="<?php echo $and_img4;?>" name="and_img4" data-validate="required,url">
                      <span class="input-group-addon"><a target="_blank" href="<?php echo $and_img4;?>"><i class="linecons-search"></i></a></span>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-6">
                    <button type="submit" type="button" class="btn btn-info">保存</button>
                  </div>
                </div>
                
              </form> 
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	<body>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>