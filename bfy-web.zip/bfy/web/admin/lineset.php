<?php
$mod='blank';
include("../api.inc.php");
$title='配置线路';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                          <h1 class="widget-heading h3 text-black"><strong><?php echo $title ?></strong></h1>
                                              <h5>此处按需要配置线路。</h5>
                                         
                                      </div>
									  
                                      <div class="col-sm-12">
                                          
                                              <ul class="breadcrumb breadcrumb-top">
                                                  <li><a href="index.php">返回首页</a></li>
                                                  <li><?php echo $title ?></li>
                                              </ul>
                                          
                                       </div>
                                  </div>
                            </div>
					<!--end--><!--end--><!--end--><!--end--><!--end--><!--end--><!--end--><!--end-->
					
					       
					
					
<?php
$id = daddslashes($_GET['id']);
?>

            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">进行线路编号为 <?=$id?> 的配置</h3>
                      
                     
                    </div>
                    <div class="panel-body">

<?php
if(!$id || !$row = $DB->get_row("select * from `open` where id='$id' limit 1")){ exit("线路不存在!");}
if($_POST['type']=="update"){
echo '<div class="alert ';
//$category_id = daddslashes($_POST['category_id']);
$name = daddslashes($_POST['name']);
$mo = daddslashes($_POST['mo']);
$linetype = daddslashes($_POST['linetype']);
  if($DB->query("update `open` set `name`='$name',`mo`='$mo',`type`='$linetype' where id='$id'")){
    echo 'alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改成功！';
  }else{
    echo 'alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改失败！'.$DB->error();
  }
echo '</div>';
echo "<style>#lineset{display: none;}</style>";
//exit;
}
?>
      

                <form id="lineset" action="./lineset.php?id=<?=$id?>" method="post" role="form" class="form-horizontal">
                <input type="hidden" name="type" value="update" />

                    <div class="form-group">
                      <label class="col-sm-2 control-label">线路名称：</label>
                      <div class="col-sm-9">
                        <input type="text" class="form-control" id="field-1" placeholder="输入模式名称" name="name" data-validate="required" value="<?=$row['name']?>">
                      </div>
                    </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label">线路类型：</label>
                    <div class="col-sm-9">
                      <label class="radio-inline">
                        <input type="radio" name="linetype" <?php if(1 == $row['type'])echo "checked=\"\"";?> value="1">
                        移动
                      </label>
                      <label class="radio-inline">
                        <input type="radio" name="linetype" <?php if(2 == $row['type'])echo "checked=\"\"";?> value="2">
                        联通
                      </label>
                      <label class="radio-inline">
                        <input type="radio" name="linetype" <?php if(3 == $row['type'])echo "checked=\"\"";?> value="3">
                        电信
                      </label>
                    </div>
                  </div>

                    <div class="form-group">
                      <label class="col-sm-2 control-label">模式内容：</label>
                      <div class="col-sm-9">
                         <textarea class="form-control" cols="5" id="field-5" name="mo" rows="25" data-validate="required"><?=$row['mo']?></textarea>
                      </div>
                    </div>   

                  <div class="form-group">
                    <label class="col-sm-2 control-label"></label>
                    <div class="col-sm-9">
                      <button type="submit" type="button" class="btn btn-info btn-block">修改</button>
                    </div>
                  </div>
                  
                </form>

                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
					
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	<body>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>