<?php
$mod='blank';
include("../api.inc.php");
$title='代理充值管理';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                          <h1 class="widget-heading h3 text-black"><strong><?php echo $title ?></strong></h1>
                                              <h5>您在此处可以管理代理充值的价格类型。</h5>
                                         
                                      </div>
									  
                                      <div class="col-sm-12">
                                          
                                              <ul class="breadcrumb breadcrumb-top">
                                                  <li><a href="index.php">返回首页</a></li>
                                                  <li><?php echo $title ?></li>
                                              </ul>
                                          
                                       </div>
                                  </div>
                            </div>
					
					
					
					
					
					
					
					
<?php
if($_POST['name']){
echo '';
$name = daddslashes($_POST['name']);
$days = daddslashes($_POST['days']);
$maxll = daddslashes($_POST['maxll'])*1024*1024;
$km_rmb = daddslashes($_POST['km_rmb']);
if(!$DB->get_row("select * from `kmtype` where `name`='$name' limit 1")){
  $sql="insert into `kmtype` (`name`,`days`,`maxll`,`km_rmb`,`i`) values ('{$name}','0','0','{$km_rmb}','1')";
  if($DB->query($sql))
    echo '<div class="alert alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  成功添加一个充值</div>
                <a href="javascript:history.go(-1)" class="btn btn-secondary btn-icon btn-icon-standalone">
                  <i class="fa-edit"></i>
                  <span>继续添加</span>
                </a>
                <a href="cztype.php" class="btn btn-info btn-icon btn-icon-standalone">
                  <i class="fa-list-ol"></i>
                  <span>查看列表</span>
                </a>
                  <style>#addtype{display: none;}</style>';
  else
    echo '<div class="alert alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>添加失败：'.$DB->error().'</div>
                <a href="javascript:history.go(-1)" class="btn btn-success btn-icon btn-icon-standalone">
                  
                  <span>继续添加</span>
                </a>
                <a href="cztype.php" class="btn btn-info btn-icon btn-icon-standalone">
                  
                  <span>查看列表</span>
                </a>
                <style>#addtype{display: none;}</style>';
}else{
  echo "<script>alert('该充值已存在！');history.go(-1);</script>";
}
echo '';
//exit;
}

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='del'){
echo '<div class="alert';
$id=$_GET['id'];
$sql=$DB->query("DELETE FROM `kmtype` WHERE id='$id'");
if($sql){echo ' alert-success">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除成功！';}
else{echo ' alert-danger">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除失败！';}
echo '</div><style>#addtype{display: none;}</style>';
}

if(!empty($_GET['kw'])) {
  $sql=" `id`='{$_GET['kw']}'";
  $numrows=$DB->count("SELECT count(*) from `kmtype` WHERE{$sql}");
  $con='包含 '.$_GET['kw'].' 的共有 '.$numrows.' 个充值类型';
}else{
  $numrows=$DB->count("SELECT count(*) from `kmtype` WHERE  `i` = '1'");
  $sql=" 1";
  $con='平台共有 '.$numrows.' 个充值类型';
}

?>

            <div id="addtype" class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title"><?php echo $con; ?></h3>
                      
                      
                    </div>
                    <div class="panel-body">
                    
                    <div id="addtype_list" class="row">
                                        <?php

                                        $rs=$DB->query("SELECT * FROM `kmtype` WHERE `i` = 1");
                                        while($res = $DB->fetch($rs))
                                        { ?>

                                        <div>
										<blockquote class="blockquote blockquote-success col-sm-12">
                                <form action="cztype.php?my=add" method="POST" class="form-inline validate col-sm-6" style="overflow: hidden;">
                                <div class="form-group">
                                  <div class="form-group">
                                    <input type="text" class="form-control" name="name" placeholder="充值名称" data-validate="required">
                                  </div>
                                  <div class="form-group">
                                    <input type="text" class="form-control" name="km_rmb" placeholder="充值额度" data-validate="required,number,min[1]">
                                  </div>
                                  <button type="submit" class="btn btn-info btn-single">添加充值</button>
                                </div>
                                </form>
                        </blockquote>
										<div class="widget col-sm-3">
										<div class="widget-content widget-content-mini themed-background">
                                        <div class="pull-right text-muted">
										<div class="xe-nav text-right">
                                                  <a href="cztype.php?my=del&id=<?=$res['id']?>" onclick="if(!confirm('你确实要删除此充值吗？')){return false;}" class="xe-next" style="color: rgba(255, 255, 255, 0.50);">
                                                    <span class="btn themed-background"> X </span>
                                                  </a>
                                                </div>
										</div><font><font>
                                        <strong><?=$res['name']?></strong>
                                    </font></font></div>
										<div class="widget-content themed-background text-light-op text-center">
                                          <div class="xe-widget xe-todo-list xe-todo-list-turquoise">
                                            <div class="xe-header">
                                            </div>
                                            <div class="xe-body">
                                              <h1>
                                              <ul class="list-unstyled">
                                                <li>
                                                  <label>
                                                    <div class="cbr-replaced cbr-checked cbr-turquoise"><div class="cbr-input"></div><div class="cbr-state"><span></span></div></div>
                                                    <span>￥<?=$res['km_rmb']?>元</span>
                                                  </label>
                                                </li>
                                                
                                              </ul>
                                               </h1>
                                            </div>
                                          </div>
                                        </div>

                                        <?php }
                                        ?>
                    </div>
                      
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
					
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	<body>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>