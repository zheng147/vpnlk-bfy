<?php
$mod='blank';
include("../api.inc.php");
$title='修改密码';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                          <h1 class="widget-heading h3 text-black"><strong><?php echo $title ?></strong></h1>
                                              <h5>管理员在这里可以修改后台密码</h5>
                                         
                                      </div>
									  
                                      <div class="col-sm-12">
                                          
                                              <ul class="breadcrumb breadcrumb-top">
                                                  <li><a href="index.php">返回首页</a></li>
                                                  <li><?php echo $title ?></li>
                                              </ul>
                                          
                                       </div>
                                  </div>
                            </div>
					
					
					
					
					<div class="row">

                <div class="col-sm-12">

                    

                  <div class="panel panel-default">

                    <div class="panel-heading">

                      <h3 class="panel-title">修改管理员账号和密码</h3>

                      

                      

                    <div class="panel-body">

<?php
if (isset($_POST['newname']) && isset($_POST['newpasswd'])) {
    $newname = $_POST['newname'];
    $newpasswd = $_POST['newpasswd'];
    if ($newname == "" || $newpasswd == "") {
        exit("<script language='javascript'>alert('用户名和密码不能为空！');history.go(-1);</script>");
    } else {
        $newpasswd = md5($newpasswd);
        $sql = "update `admin` set `username` = '" . $newname . "', `password` = '" . $newpasswd . "'";
        $result = $DB->query($sql);
        if ($result) {
            exit("<script language='javascript'>alert('密码修改成功！');history.go(-1);</script>");
        } else {
            exit("<script language='javascript'>alert('密码修改失败！');history.go(-1);</script>");
        }
    }
}
?>



              <form id="myform" action="./passwd.php" method="post" role="form" class="form-horizontal validate">     

                <div class="form-group">		
				
                  <label class="col-sm-2 control-label">新账号</label>

                  <div class="col-sm-10">

                    <input type="text" class="form-control" id="field-1" name="newname" data-validate="required">

                  </div>

                </div>

				
                <div class="form-group">

                  <label class="col-sm-2 control-label">新密码</label>

                  <div class="col-sm-10">

                    <input type="text" class="form-control" id="field-1" name="newpasswd" data-validate="required">

                  </div>

                </div>




                <div class="form-group">

                  <label class="col-sm-2 control-label"></label>

                  <div class="col-sm-6">

                    <button type="submit" type="button" class="btn btn-info">修改</button>

                  </div>

                </div>

                

              </form> 

                      

                    </div>

                  

                  </div>

                    

                </div>



            </div>

					
					
					
					
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	<body>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>