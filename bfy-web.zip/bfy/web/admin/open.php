<?php
$mod='blank';
include("../api.inc.php");
$title='添加线路';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                          <h1 class="widget-heading h3 text-black"><strong><?php echo $title ?></strong></h1>
                                              <h5>您可以在此处添加线路。</h5>
                                         
                                      </div>
									  
                                      <div class="col-sm-12">
                                          
                                              <ul class="breadcrumb breadcrumb-top">
                                                  <li><a href="index.php">返回首页</a></li>
                                                  <li><?php echo $title ?></li>
                                              </ul>
                                          
                                       </div>
                                  </div>
                            </div>
					
					
					
					
				
					
					
					
					
					<div class="row ">
                <div class="col-sm-12">

<?php
$open=isset($_POST['open'])?$_POST['open']:null;

if($open=='open1'){
echo '<div class="alert '; 
$name = $_REQUEST['name']; 
$proxy = $_REQUEST['proxy'];
$ca = $_REQUEST['ca']; 
$key = $_REQUEST['key']; 
$mo ='# 缤纷云控云免配置 '.$name.'
client
dev tun
proto tcp
########免流代码########
'.$proxy.'
########免流代码########
resolv-retry infinite
nobind
persist-key
persist-tun
setenv IV_GUI_VER "de.blinkt.openvpn 0.6.17"
push route 114.114.114.144 114.114.115.115
machine-readable-output
connect-retry-max 5
connect-retry 5
resolv-retry 60
auth-user-pass
ns-cert-type server
comp-lzo
verb 3

## 证书
<ca>
'.$ca.'
</ca>
key-direction 1
<tls-auth>
'.$key.'
</tls-auth>

';
$type = $_REQUEST['type'];   
$id=strtoupper(substr(md5($uin.time()),0,8).'-'.uniqid()); 
$sql="insert INTO `ov`. `open` (`id`,`name`,`mo`,`type`) values ('{$id}','{$name}','{$mo}','{$type}')"; 
$llws = $_REQUEST['llws'];   
if($llws=='1'){
  $time=time(); 
  $DB->query("insert INTO `ov`. `line`(`id`,`name`,`content`,`group`,`time`,`show`) values(null,'$name','$mo','$type','$time','1');");
}
if($DB->query($sql))
echo 'alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>成功添加一个线路</div>
                <a href="open.php" class="btn btn-secondary btn-icon btn-icon-standalone">
                  
                  <span>继续添加</span>
                </a>
                <a href="openlist.php" class="btn btn-info btn-icon btn-icon-standalone">
                  
                  <span>查看列表</span>
                </a>
                <style>#addline{display: none;}</style>'; 
else
                echo 'alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  添加失败</div>
                <a href="open.php" class="btn btn-secondary btn-icon btn-icon-standalone">
                  
                  <span>继续添加</span>
                </a>
                <a href="openlist.php" class="btn btn-info btn-icon btn-icon-standalone">
                  
                  <span>查看列表</span>
                </a>
                <style>#addline{display: none;}</style>'; 
//exit;  
}

if($open=='open2'){
echo '<div class="alert '; 
$name = $_REQUEST['name']; 
$mo = $_REQUEST['mo'];   
$type = $_REQUEST['type'];   
$id=strtoupper(substr(md5($uin.time()),0,8).'-'.uniqid()); 
$sql="insert into `ov`. `open` (`id`,`name`,`mo`,`type`) values ('{$id}','{$name}','{$mo}','{$type}')"; 
$llws = $_REQUEST['llws'];   
if($llws=='1'){
  $time=time(); 
  $DB->query("insert INTO `ov`. `line`(`id`,`name`,`content`,`group`,`time`,`show`) values(null,'$name','$mo','$type','$time','1');");
}
if($DB->query($sql))
echo 'alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>成功添加一个线路</div>
                <a href="open.php" class="btn btn-secondary">
                 
                  <span>继续添加</span>
                </a>
                <a href="openlist.php" class="btn btn-info">
                  
                  <span>查看列表</span>
                </a>
                <style>#addline{display: none;}</style>'; 
else
                echo 'alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  添加失败</div>
                <a href="open.php" class="btn btn-secondary">
                  
                  <span>继续添加</span>
                </a>
                <a href="openlist.php" class="btn btn-info ">
                  
                  <span>查看列表</span>
                </a>
                <style>#addline{display: none;}</style>'; 
//exit;  
}

?>

                <div id="addline">
                      <ul class="nav nav-tabs">
                        <li class="active">
                          <a href="#profile" data-toggle="tab">
                            <span class="visible-xs">高级模式</span>
                            <span class="hidden-xs">高级模式</span>
                          </a>
                        </li>
                        <li class="">
                          <a href="#by" data-toggle="tab">
                            <span class="visible-xs">简约模式</span>
                            <span class="hidden-xs">简约模式</span>
                          </a>
                        </li>
                      </ul>
					  
                      <div class="tab-content block full">
                        <div class="tab-pane active" id="profile">
                          <form id="newopen" action="./open.php" method="post" class="form-horizontal validate" role="form">
                            <input type="text" class="hide" name="open" value="open1">
                            <div class="form-group">
                              <label class="col-sm-2 control-label">线路名称：</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="proxy_title" placeholder="输入线路名称" name="name" data-validate="required">
                              </div>
                            </div>

                        <div class="form-group">
                          <label class="col-sm-2 control-label">线路类型：</label>
                          <div class="col-sm-9">
                            <label class="radio-inline">
                              <input type="radio" name="type" checked="" value="1">
                              移动
                            </label>
                            <label class="radio-inline">
                              <input type="radio" name="type" value="2">
                              联通
                            </label>
                            <label class="radio-inline">
                              <input type="radio" name="type" value="3">
                              电信
                            </label>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-sm-2 control-label">同步至流量卫士：</label>
                          <div class="col-sm-9">
                            <label class="radio-inline">
                              <input type="radio" name="llws" checked="" value="1">
                              是
                            </label>
                            <label class="radio-inline">
                              <input type="radio" name="llws" value="2">
                              否
                            </label>
                          </div>
                        </div>
                            <div class="form-group">
                              <label class="col-sm-2 control-label">免流模式：</label>
                              <div class="col-sm-6">
                                 <textarea class="form-control jq_watermark" cols="5" id="proxy" name="proxy" rows="11" data-validate="required" placeholder='
##-------------------指向链接--------------------##
remote wap.gd.10086.cn 80
##-------------------代理部分--------------------##
http-proxy 【您的IP】 【免流端口】
http-proxy-option EXT1 【验证头】 127.0.0.1:【VPN端口】
http-proxy-option EXT1 "X-Online-Host: wap.gd.10086.cn" 
http-proxy-option EXT1 "Host: wap.gd.10086.cn"'></textarea>
                              <p class="text-info" style="line-height: 31px;">* 以上是基础示例，【】为特殊提示可删除，默认验证头为vpn 默认VPN端口为443</p>
                              </div>
							   
                              <?php 
                              $url = "http://data.awayun.cn/admin/xianlu.php"; 
                              $xianlu = file_get_contents($url); 
                              echo $xianlu; 
                              ?>
                            </div>  
                            <div class="form-group">
                              <label class="col-sm-2 control-label">您的证书：</label>
                              <div class="col-sm-9">
                                 <textarea class="form-control" cols="5" id="field-5" name="ca" rows="6" data-validate="required"><?php
                                      $myfile = fopen("../ca.crt", "r") or die("没有找到ca.crt");
                                      echo fread($myfile,filesize("../ca.crt"));
                                      fclose($myfile);
                                      ?></textarea>
                              </div>
                            </div>  

                            <div class="form-group">
                              <label class="col-sm-2 control-label">您的Key：</label>
                              <div class="col-sm-9">
                                 <textarea class="form-control" cols="5" id="field-5" name="key" rows="6" data-validate="required"><?php
                                      $myfile = fopen("../ta.key", "r") or die("没有找到ta.key");
                                      echo fread($myfile,filesize("../ta.key"));
                                      fclose($myfile);
                                      ?></textarea>
                              </div>
                            </div>  

                            <div class="form-group">
                              <label class="col-sm-2 control-label"></label>
                              <div class="col-sm-9">
                                <button type="submit" type="button" class="btn btn-info btn-block">添加</button>
                              </div>
                            </div>
                          </form>
                        </div>
                        <div class="tab-pane" id="by">
                          <form id="open" action="./open.php" method="post" class="form-horizontal validate" role="form">
                            <input type="text" class="hide" name="open" value="open2">
                            <div class="form-group">
                              <label class="col-sm-2 control-label">线路名称：</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="field-1" placeholder="输入线路名称" name="name" data-validate="required">
                              </div>
                            </div>

                        <div class="form-group">
                          <label class="col-sm-2 control-label">线路类型：</label>
                          <div class="col-sm-9">
                            <label class="radio-inline">
                              <input type="radio" name="type" checked="" value="1">
                              移动
                            </label>
                            <label class="radio-inline">
                              <input type="radio" name="type" value="2">
                              联通
                            </label>
                            <label class="radio-inline">
                              <input type="radio" name="type" value="3">
                              电信
                            </label>
                          </div>
                        </div>
                        
                        <div class="form-group">
                          <label class="col-sm-2 control-label">同步至流量卫士：</label>
                          <div class="col-sm-9">
                            <label class="radio-inline">
                              <input type="radio" name="llws" checked="" value="1">
                              是
                            </label>
                            <label class="radio-inline">
                              <input type="radio" name="llws" value="2">
                              否
                            </label>
                          </div>
                        </div>

                            <div class="form-group">
                              <label class="col-sm-2 control-label">线路内容：</label>
                              <div class="col-sm-9">
                                 <textarea class="form-control" cols="5" id="field-5" name="mo" rows="25" data-validate="required"></textarea>
                              </div>
                            </div>  

                            <div class="form-group">
                              <label class="col-sm-2 control-label"></label>
                              <div class="col-sm-9">
                                <button type="submit" type="button" class="btn btn-info btn-block">添加</button>
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>
                </div>
                    
                </div>

            </div>
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	<body>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>