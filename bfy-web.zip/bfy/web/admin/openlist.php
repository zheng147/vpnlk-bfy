<?php
$mod='blank';
include("../api.inc.php");
$title='已有线路';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					
					
<?php

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='del'){
echo '<div class="alert';
$id=$_GET['id'];
$sql=$DB->query("DELETE FROM `open` WHERE id='$id'");
if($sql){echo ' alert-success">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除成功！';}
else{echo ' alert-danger">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除失败！';}
echo '</div><style>.tab-pane{display: none;}</style>';
}else
{
if(!empty($_GET['kw'])) {
  $sql=" `iuser`='{$_GET['kw']}'";
  $numrows=$DB->count("SELECT count(*) from `open` WHERE{$sql}");
  $con='包含 '.$_GET['kw'].' 的共有 '.$numrows.' 个线路';
}else{
  $numrows=$DB->count("SELECT count(*) from `open` WHERE 1");
  $sql=" 1";
  $con='平台共有 '.$numrows.' 个线路';
}
?>
					
					
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                          <h1 class="widget-heading h3 text-black"><strong><?php echo $title ?></strong></h1>
                                              <h5>提示： 代理商余额为0将不显示线路！</h5>
                                         
                                      </div>
									  
                                      <div class="col-sm-12">
                                          
                                              <ul class="breadcrumb breadcrumb-top">
                                                  <li><a href="index.php">返回首页</a></li>
                                                  <li><?php echo $title ?></li>
                                              </ul>
                                          
                                       </div>
                                  </div>
                            </div>
					
					
					
					
					
					
			<div class="widget-content themed-background-muted text-center">		

				<div class="row">
            <div class="col-md-12" id="openlist">
			
<?php
if($my=='qk'){//清空线路
echo '<div class="alert alert-warning">
                                        <button type="button" class="close" data-dismiss="alert">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span></button>
您确认要清空所有线路吗？清空后无法恢复！</div><a href="./openlist.php?my=qk2" class="btn btn-red">确定清空</a><a href="javascript:history.back();" class="btn btn-white">返回</a></div></div>';
}
if($my=='qk2'){//清空线路结果
echo '<div class="alert';
if($DB->query("DELETE FROM open")==true){
echo ' alert-success">
                                        <button type="button" class="close" data-dismiss="alert">
                      <span aria-hidden="true">×</span>
                      <span class="sr-only">Close</span>
                    </button>清空成功！';
}else{
echo' alert-danger">
                                        <button type="button" class="close" data-dismiss="alert">
                      <span aria-hidden="true">×</span>
                      <span class="sr-only">Close</span>
                    </button>清空失败！';
}
echo '</div>';
}
?>
                <ul class="nav nav-tabs">
                  <li class="active">
                    <a href="#others" data-toggle="tab">
                      <span class="visible-xs">全部</span>
                      <span class="hidden-xs">全部</span>
                    </a>
                  </li>
                  <li class="">
                    <a href="#home" data-toggle="tab">
                      <span class="visible-xs">移动</span>
                      <span class="hidden-xs">移动</span>
                    </a>
                  </li>
                  <li class="">
                    <a href="#profile" data-toggle="tab">
                      <span class="visible-xs">联通</span>
                      <span class="hidden-xs">联通</span>
                    </a>
                  </li>
                  <li class="">
                    <a href="#messages" data-toggle="tab">
                      <span class="visible-xs">电信</span>
                      <span class="hidden-xs">电信</span>
                    </a>
                  </li>
                  </li>
                </ul>
                
                <div class="tab-content block all">
                  <div class="tab-pane active" id="others">
                      <div class="table-responsive">
                      
                                  <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                      <thead>
                                          <tr>
                                            <th>线路ID</th>
                                            <!--th data-priority="1">线路类型</th-->
                                            <th data-priority="3">名称</th>
                                            <th data-priority="6">内容</th>
                                            <!--th data-priority="6">添加时间</th-->
                                            <th data-priority="6">操作</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                        <?php
                                        $pagesize=10;
                                        $pages=intval($numrows/$pagesize);
                                        if ($numrows%$pagesize)
                                        {
                                         $pages++;
                                         }
                                        if (isset($_GET['page'])){
                                        $page=intval($_GET['page']);
                                        }
                                        else{
                                        $page=1;
                                        }
                                        $offset=$pagesize*($page - 1);
                                        //$zt = array('0'=>'<font color=green>正常</font>','1'=>'<font color=red>密码错误</font>','2'=>'<font color=red>冻结</font>','3'=>'<font color=red>开启设备锁</font>');
                                        $rs=$DB->query("SELECT * FROM `open` WHERE{$sql} order by id desc limit $offset,$pagesize");

                                        //$category = array('','<span class="badge badge-info">移动</span>','<span class="badge badge-danger">联通</span>','<span class="badge badge-secondary">电信</span>');

                                        while($res = $DB->fetch($rs))
                                        { ?>
                                        <tr>
                                        <th><span class="co-name"><?=$res['id']?></span></th>
                                        <!--td><?=$category[$res['category_id']]?></td-->
                                        <td><?=$res['name']?></td>
                                        <td><pre style="
    height: 100px;
"><?=$res['mo']?></pre></td>
                                        <!--td><?=date("Y-m-d",$res['timeline'])?></td-->
                                        <td><a class="btn btn-xs btn-success" href="./down.php?id=<?=$res['id']?>">下载</a><a class="btn btn-xs btn-turquoise" href="./lineset.php?id=<?=$res['id']?>">配置</a>&nbsp;<a href="./openlist.php?my=del&id=<?=$res['id']?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要删除此线路吗？')){return false;}">删除</a>&nbsp;</td>
                                        </tr>

                                        <?php }
                                        ?>
                                      </tbody>
                                  </table>
                      
                      </div>
                      
                      <?php
                      echo'<ul class="pagination pagination-sm">';
                      $first=1;
                      $prev=$page-1;
                      $next=$page+1;
                      $last=$pages;
                      if ($page>1)
                      {
                      echo '<li><a href="openlist.php?page='.$first.$link.'">首页</a></li>';
                      echo '<li><a href="openlist.php?page='.$prev.$link.'">&laquo;</a></li>';
                      } else {
                      echo '<li class="disabled"><a>首页</a></li>';
                      echo '<li class="disabled"><a>&laquo;</a></li>';
                      }
                      for ($i=1;$i<$page;$i++)
                      echo '<li><a href="openlist.php?page='.$i.$link.'">'.$i .'</a></li>';
                      echo '<li class="disabled"><a>'.$page.'</a></li>';
                      for ($i=$page+1;$i<=$pages;$i++)
                      echo '<li><a href="openlist.php?page='.$i.$link.'">'.$i .'</a></li>';
                      echo '';
                      if ($page<$pages)
                      {
                      echo '<li><a href="openlist.php?page='.$next.$link.'">&raquo;</a></li>';
                      echo '<li><a href="openlist.php?page='.$last.$link.'">尾页</a></li>';
                      } else {
                      echo '<li class="disabled"><a>&raquo;</a></li>';
                      echo '<li class="disabled"><a>尾页</a></li>';
                      }
                      echo'</ul>';
                      #分页
                      }
                      ?>
                  </div>
                  <div class="tab-pane" id="home">
                      
                      
                      <div class="table-responsive">
                                  <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                      <thead>
                                          <tr>
                                            <th>线路ID</th>
                                            <!--th data-priority="1">线路类型</th-->
                                            <th data-priority="3">名称</th>
                                            <th data-priority="6">内容</th>
                                            <!--th data-priority="6">添加时间</th-->
                                            <th data-priority="6">操作</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                        <?php
                                        $rs=$DB->query("SELECT * FROM `open` WHERE  `type` = 1 ");
                                        while($res = $DB->fetch($rs))
                                        { ?>
                                        <tr>
                                        <th><span class="co-name"><?=$res['id']?></span></th>
                                        <!--td><?=$category[$res['category_id']]?></td-->
                                        <td><?=$res['name']?></td>
                                        <td><pre class="background"style="height: 100px;"><?=$res['mo']?></pre></td>
                                        <!--td><?=date("Y-m-d",$res['timeline'])?></td-->
                                        <td><a class="btn btn-xs btn-success" href="./down.php?id=<?=$res['id']?>">下载</a><a class="btn btn-xs btn-turquoise" href="./lineset.php?id=<?=$res['id']?>">配置</a>&nbsp;<a href="./openlist.php?my=del&id=<?=$res['id']?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要删除此线路吗？')){return false;}">删除</a>&nbsp;</td>
                                        </tr>
                                        <?php }
                                        ?>
                                      </tbody>
                                  </table>
                      </div>
                 
                  </div>
                  <div class="tab-pane" id="profile">
                      
                      <div class="table-responsive">
                                  <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                      <thead>
                                          <tr>
                                            <th>线路ID</th>
                                            <!--th data-priority="1">线路类型</th-->
                                            <th data-priority="3">名称</th>
                                            <th data-priority="6">内容</th>
                                            <!--th data-priority="6">添加时间</th-->
                                            <th data-priority="6">操作</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                        <?php
                                        $rs=$DB->query("SELECT * FROM `open` WHERE  `type` = 2 ");
                                        while($res = $DB->fetch($rs))
                                        { ?>
                                        <tr>
                                        <th><span class="co-name"><?=$res['id']?></span></th>
                                        <!--td><?=$category[$res['category_id']]?></td-->
                                        <td><?=$res['name']?></td>
                                        <td><pre class="background"style="height: 100px;"><?=$res['mo']?></pre></td>
                                        <!--td><?=date("Y-m-d",$res['timeline'])?></td-->
                                        <td><a class="btn btn-xs btn-success" href="./down.php?id=<?=$res['id']?>">下载</a><a class="btn btn-xs btn-turquoise" href="./lineset.php?id=<?=$res['id']?>">配置</a>&nbsp;<a href="./openlist.php?my=del&id=<?=$res['id']?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要删除此线路吗？')){return false;}">删除</a>&nbsp;</td>
                                        </tr>
                                        <?php }
                                        ?>
                                      </tbody>
                                  </table>
                      </div>
                  </div>
                  <div class="tab-pane" id="messages">
                      <div class="table-responsive">
                                  <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                      <thead>
                                          <tr>
                                            <th>线路ID</th>
                                            <!--th data-priority="1">线路类型</th-->
                                            <th data-priority="3">名称</th>
                                            <th data-priority="6">内容</th>
                                            <!--th data-priority="6">添加时间</th-->
                                            <th data-priority="6">操作</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                        <?php
                                        $rs=$DB->query("SELECT * FROM `open` WHERE  `type` = 3 ");
                                        while($res = $DB->fetch($rs))
                                        { ?>
                                        <tr>
                                        <th><span class="co-name"><?=$res['id']?></span></th>
                                        <!--td><?=$category[$res['category_id']]?></td-->
                                        <td><?=$res['name']?></td>
                                        <td><pre class="background"style="height: 100px;"><?=$res['mo']?></pre></td>
                                        <!--td><?=date("Y-m-d",$res['timeline'])?></td-->
                                        <td><a class="btn btn-xs btn-success" href="./down.php?id=<?=$res['id']?>">下载</a><a class="btn btn-xs btn-turquoise" href="./lineset.php?id=<?=$res['id']?>">配置</a>&nbsp;<a href="./openlist.php?my=del&id=<?=$res['id']?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要删除此线路吗？')){return false;}">删除</a>&nbsp;</td>
                                        </tr>
                                        <?php }
                                        ?>
                                      </tbody>
                                  </table>
                      </div>
                  </div>
                </div>
                
              </div>


            </div></div>	
					
					
					
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	<body>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>