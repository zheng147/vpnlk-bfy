<?php
/**
 * 管理中心
**/
$mod='blank';
include("../api.inc.php");
$title='管理中心';

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $rs = $DB->get_row("SELECT * FROM `auth_fwq` WHERE `id`='$id' limit 1");
    if(!$rs){
        echo "此服务器不存在";
    }else{
        $file = 'http://'.$rs['ipport'].'/res/tcp.txt';
        $file2 = 'http://'.$rs['ipport'].'/udp/udp.txt';
    }
}else{
    $file = '../res/tcp.txt';
    $file2 = '../udp/udp.txt';
}
?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
   
   
   
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
                    <!-- Page content -->
                    <div id="page-content">
                        <!-- First Row -->
                        <div class="row">
						<?php
                          $rs=$DB->query("SELECT * FROM `auth_fwq` order by id desc");
                          while($res = $DB->fetch($rs))
                          {
                          $str=file_get_contents('http://'. $res['ipport'] .'/res/tcp.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                          $str2=file_get_contents('http://'. $res['ipport'] .'/udp/udp.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                          $onlinenum_tcp = (substr_count($str,date('Y'))-1)/2;
                          $onlinenum_udp = (substr_count($str2,date('Y'))-1)/2;
                          $onlinenum =$onlinenum_tcp+$onlinenum_udp;
                          if($onlinenum < 0)
                            $onlinetext = '0';
                          else
                            $onlinetext = (int)$onlinenum;
                            $indexnum = $indexnum + $onlinetext;
                           }
                          ?>
                            <!-- Simple Stats Widgets -->
                            <div class="col-sm-6 col-lg-3">
                                <a href="javascript:void(0)" class="widget">
                                    <div class="widget-content widget-content-mini text-right clearfix">
                                        <div class="widget-icon pull-left themed-background">
                                            <i class="gi gi-cardio text-light-op"></i>
                                        </div>
                                        <h2 class="widget-heading h3">
                                            <strong><span data-toggle="counter" data-to="<?php echo $indexnum ?>"></span></strong>
                                        </h2>
                                        <span class="text-muted">在线用户</span>
                                    </div>
                                </a>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <a href="javascript:void(0)" class="widget">
                                    <div class="widget-content widget-content-mini text-right clearfix">
                                        <div class="widget-icon pull-left themed-background-success">
                                            <i class="gi gi-user text-light-op"></i>
                                        </div>
                                        <h2 class="widget-heading h3 text-success">
                                            <strong><span data-toggle="counter" data-to="<?php echo $count?>"></span></strong>
                                        </h2>
                                        <span class="text-muted">注册用户</span>
                                    </div>
                                </a>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <a href="javascript:void(0)" class="widget">
                                    <div class="widget-content widget-content-mini text-right clearfix">
                                        <div class="widget-icon pull-left themed-background-warning">
                                            <i class="gi gi-briefcase text-light-op"></i>
                                        </div>
                                        <h2 class="widget-heading h3 text-warning">
                                            <strong><span data-toggle="counter" data-to="<?php echo $countkm?>"></span></strong>
                                        </h2>
                                        <span class="text-muted">已生成卡密</span>
                                    </div>
                                </a>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <a href="javascript:void(0)" class="widget">
                                    <div class="widget-content widget-content-mini text-right clearfix">
                                        <div class="widget-icon pull-left themed-background-danger">
                                            <i class="gi gi-wallet text-light-op"></i>
                                        </div>
                                        <h2 class="widget-heading h3 text-danger">
                                            <strong><span data-toggle="counter" data-to="<?php echo $countdaili?>"></span></strong>
                                        </h2>
                                        <span class="text-muted">已注册代理</span>
                                    </div>
                                </a>
                            </div>
                            <!-- END Simple Stats Widgets -->
                        </div>
                        <!-- END First Row -->

                        <!-- Second Row -->
                        <div class="row">
                            
                            <div class="col-sm-6 col-lg-4">
                                <!-- Stats User Widget -->
                                <a  class="widget">
                                    
									
									<div class="widget-content themed-background-info text-light-op">
                                                <i class="fa fa-fw fa-chevron-right"></i> <strong><font><font>平台首页</font></font></strong>
                                            </div>
									
									
									
									
                                    <div class="widget-content border-bottom text-center  themed-background">
                                        <img src="../asset/img/placeholders/avatars/avatar13@2x.jpg" alt="avatar" class="img-circle img-thumbnail img-thumbnail-avatar-2x">
                                        <h2 class="widget-heading h3 text-dark"><br>你好！管理员</h2>
                                        
                                    </div>
                                    <div class="widget-content widget-content-full-top-bottom">
                                        <div class="row text-center">
                                            <div class="col-xs-6 push-inner-top-bottom border-right">
                                                <div class="widget-content text-dark text-center">
												<?php include '../banben.php';?>
                                            </div>
											</div>
                                            <?php
                              $url = "http://data.awayun.cn/admin/zuixinbanben.php"; 
                              $zuixinbanben = file_get_contents($url); 
                              echo $zuixinbanben; 
                              ?>
                                        </div>
                                    </div>
                                </a>
                                
								<?php include 'infwq.php';?>
								
								
								
                               
                            </div>
							
							
						<?php
                              $url = "http://data.awayun.cn/admin/ytsxl.php"; 
                              $ytsxl = file_get_contents($url); 
                              echo $ytsxl; 
                              ?>
							
							
							
                              	<?php
                              $url = "http://data.awayun.cn/admin/yunmianjiqiao.php"; 
                              $yunmianjiqiao = file_get_contents($url); 
                              echo $yunmianjiqiao; 
                              ?>
                                
                               
                            </div>
							
                        </div>
                        
                        <div class="row">
                        </div>
                      
                    </div>
                   
                </div>
               
            </div>
           
        </div>
        

       
        <script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
    </body>
</html>