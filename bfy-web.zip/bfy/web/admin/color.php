<div id="sidebar-alt" tabindex="-1" aria-hidden="true">
                    <!-- Toggle Alternative Sidebar Button (visible only in static layout) -->
                    <a href="javascript:void(0)" id="sidebar-alt-close" onclick="App.sidebar('toggle-sidebar-alt');"><i class="fa fa-times"></i></a>

                    <!-- Wrapper for scrolling functionality -->
                    <div id="sidebar-scroll-alt">
                        <!-- Sidebar Content -->
                        <div class="sidebar-content">
                            <!-- Profile -->
                            <div class="sidebar-section">
                                <div class="sidebar-section sidebar-nav-mini-hide">
                                <div class="sidebar-separator push">
                                    <i class="fa fa-ellipsis-h"></i>
                                </div>
                                <ul class="sidebar-themes clearfix">
                                    <li class="">
                                        <a href="javascript:void(0)" class="themed-background-default" data-toggle="tooltip" title="" data-theme="default" data-theme-navbar="navbar-inverse" data-theme-sidebar="" data-original-title="Default">
                                            <span class="section-side themed-background-dark-default"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li class="active">
                                        <a href="javascript:void(0)" class="themed-background-classy" data-toggle="tooltip" title="" data-theme="../asset/css/themes/classy.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="" data-original-title="Classy">
                                            <span class="section-side themed-background-dark-classy"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="themed-background-social" data-toggle="tooltip" title="" data-theme="../asset/css/themes/social.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="" data-original-title="Social">
                                            <span class="section-side themed-background-dark-social"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="themed-background-flat" data-toggle="tooltip" title="" data-theme="../asset/css/themes/flat.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="" data-original-title="Flat">
                                            <span class="section-side themed-background-dark-flat"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="themed-background-amethyst" data-toggle="tooltip" title="" data-theme="../asset/css/themes/amethyst.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="" data-original-title="Amethyst">
                                            <span class="section-side themed-background-dark-amethyst"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="themed-background-creme" data-toggle="tooltip" title="" data-theme="../asset/css/themes/creme.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="" data-original-title="Creme">
                                            <span class="section-side themed-background-dark-creme"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="themed-background-passion" data-toggle="tooltip" title="" data-theme="../asset/css/themes/passion.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="" data-original-title="Passion">
                                            <span class="section-side themed-background-dark-passion"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="themed-background-default" data-toggle="tooltip" title="" data-theme="default" data-theme-navbar="navbar-inverse" data-theme-sidebar="sidebar-light" data-original-title="Default + Light Sidebar">
                                            <span class="section-side"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="themed-background-classy" data-toggle="tooltip" title="" data-theme="../asset/css/themes/classy.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="sidebar-light" data-original-title="Classy + Light Sidebar">
                                            <span class="section-side"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="themed-background-social" data-toggle="tooltip" title="" data-theme="../asset/css/themes/social.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="sidebar-light" data-original-title="Social + Light Sidebar">
                                            <span class="section-side"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="themed-background-flat" data-toggle="tooltip" title="" data-theme="../asset/css/themes/flat.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="sidebar-light" data-original-title="Flat + Light Sidebar">
                                            <span class="section-side"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="themed-background-amethyst" data-toggle="tooltip" title="" data-theme="../asset/css/themes/amethyst.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="sidebar-light" data-original-title="Amethyst + Light Sidebar">
                                            <span class="section-side"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="themed-background-creme" data-toggle="tooltip" title="" data-theme="../asset/css/themes/creme.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="sidebar-light" data-original-title="Creme + Light Sidebar">
                                            <span class="section-side"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="themed-background-passion" data-toggle="tooltip" title="" data-theme="../asset/css/themes/passion.css" data-theme-navbar="navbar-inverse" data-theme-sidebar="sidebar-light" data-original-title="Passion + Light Sidebar">
                                            <span class="section-side"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="themed-background-default" data-toggle="tooltip" title="" data-theme="default" data-theme-navbar="navbar-default" data-theme-sidebar="" data-original-title="Default + Light Header">
                                            <span class="section-header"></span>
                                            <span class="section-side themed-background-dark-default"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="themed-background-classy" data-toggle="tooltip" title="" data-theme="../asset/css/themes/classy.css" data-theme-navbar="navbar-default" data-theme-sidebar="" data-original-title="Classy + Light Header">
                                            <span class="section-header"></span>
                                            <span class="section-side themed-background-dark-classy"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="themed-background-social" data-toggle="tooltip" title="" data-theme="../asset/css/themes/social.css" data-theme-navbar="navbar-default" data-theme-sidebar="" data-original-title="Social + Light Header">
                                            <span class="section-header"></span>
                                            <span class="section-side themed-background-dark-social"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="themed-background-flat" data-toggle="tooltip" title="" data-theme="../asset/css/themes/flat.css" data-theme-navbar="navbar-default" data-theme-sidebar="" data-original-title="Flat + Light Header">
                                            <span class="section-header"></span>
                                            <span class="section-side themed-background-dark-flat"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="themed-background-amethyst" data-toggle="tooltip" title="" data-theme="../asset/css/themes/amethyst.css" data-theme-navbar="navbar-default" data-theme-sidebar="" data-original-title="Amethyst + Light Header">
                                            <span class="section-header"></span>
                                            <span class="section-side themed-background-dark-amethyst"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="themed-background-creme" data-toggle="tooltip" title="" data-theme="../asset/css/themes/creme.css" data-theme-navbar="navbar-default" data-theme-sidebar="" data-original-title="Creme + Light Header">
                                            <span class="section-header"></span>
                                            <span class="section-side themed-background-dark-creme"></span>
                                            <span class="section-content"></span>
                                        </a>
                                    </li>
                                    
                                </ul>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>