<?php
$mod='blank';
include("../api.inc.php");
$title='配置服务器';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html class="no-js" >
   <?php include 'head.php';?>
    <body>
        <div id="page-wrapper" class="page-loading">
            <!-- loading.php -->
			<?php include 'loading.php';?>
            <div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
                
                <?php include 'color.php';?>
                <?php include 'nav.php';?>
                <div id="main-container">
                    <?php include 'header.php';?>
					    <div id="page-content">
                        <div class="content-header">
                                  <div class="row">
                                      <div class="col-sm-12">
                                          <h1 class="widget-heading h3 text-black"><strong><?php echo $title ?></strong></h1>
                                              <h5>此处按需要配置服务器。</h5>
                                         
                                      </div>
									  
                                      <div class="col-sm-12">
                                          
                                              <ul class="breadcrumb breadcrumb-top">
                                                  <li><a href="index.php">返回首页</a></li>
                                                  <li><?php echo $title ?></li>
                                              </ul>
                                          
                                       </div>
                                  </div>
                            </div>
					<!--end--><!--end--><!--end--><!--end--><!--end--><!--end--><!--end--><!--end-->
					
					       
					
					
					
					
					
<?php
$id = daddslashes($_GET['id']);
?>

            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">进行服务器编号为 <?=$id?> 的配置</h3>
                      
                     
                    </div>
                    <div class="panel-body">

<?php
$row = $DB->get_row("select * from `auth_fwq` where id='$id' limit 1");
if($_POST['type']=="update"){
echo '<div class="alert ';
$fwqid = daddslashes($_POST['fwqid']);
$name = daddslashes($_POST['name']);
$ipport = daddslashes($_POST['ipport']);
  if($DB->query("update `auth_fwq` set `id`='$fwqid',`name`='$name',`ipport`='$ipport' where id='$id'")){
    echo 'alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改成功！';
  }else{
    echo 'alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改失败！'.$DB->error();
  }
echo '</div>';
echo "<style>#fwqset{display: none;}</style>";
//exit;
}
?>
      

                <form id="fwqset" action="./fwqset.php?id=<?=$id?>" method="post" role="form" class="form-horizontal">
                <input type="hidden" name="type" value="update" />

                  <div class="form-group">
                    <label class="col-sm-2 control-label">服务器ID</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" placeholder="请输入服务器ID" name="fwqid" data-validate="required" value="<?=$row['id']?>">
                    </div>
                  </div>  

                  <div class="form-group">
                    <label class="col-sm-2 control-label">服务器名称</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="name" data-validate="required" value="<?=$row['name']?>">
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label">服务器名称</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="ipport" data-validate="required" value="<?=$row['ipport']?>">
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label"></label>
                    <div class="col-sm-9">
                      <button type="submit" type="button" class="btn btn-info btn-block">修改</button>
                    </div>
                  </div>
                  
                </form>

                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
					
					
					
					
					      
					</div>
				</div>
			</div>
		</div>
	<body>
	<script src="../asset/js/vendor/jquery-2.2.4.min.js"></script>
        <script src="../asset/js/vendor/bootstrap.min.js"></script>
        <script src="../asset/js/plugins.js"></script>
        <script src="../asset/js/app.js"></script>

        <!-- Load and execute javascript code used only in this page -->
        <script src="../asset/js/pages/readyDashboard.js"></script>
        <script>$(function(){ ReadyDashboard.init(); });</script>
</html>